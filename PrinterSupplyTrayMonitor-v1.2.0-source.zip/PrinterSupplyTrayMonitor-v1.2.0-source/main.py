#!/usr/bin/env python3
"""Printer Supply & Tray Monitor.

Features:
- Pulls printer status from a WEPA monitoring page.
- Detects red/yellow alerts for toner/ink/drum/belt/fuser and down printers.
- Detects empty trays and tracks empty/filled events over time.
- Classifies printers into Pollock, Findlay, and Pattee.
- Exports tray events to CSV.
- Generates copyable ServiceNow work notes and descriptions for selected empty trays.
"""

from __future__ import annotations

import csv
import importlib
import json
import os
import random
import re
import shutil
import subprocess
import sys
import threading
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime
from html import unescape
from pathlib import Path
from typing import Any


def _tk_install_help() -> str:
    if sys.platform == "darwin":
        return (
            "Tkinter is not available. Automatic install was attempted but failed.\n"
            "Install Python with Tk support, then run this app again.\n"
            "Recommended: `brew install python-tk@3.12`."
        )
    if sys.platform.startswith("win"):
        return (
            "Tkinter is not available. Automatic install was attempted but failed.\n"
            "Reinstall Python from python.org and include 'tcl/tk and IDLE', then run this app again."
        )
    return (
        "Tkinter is not available. Automatic install was attempted but failed.\n"
        "Install your distro package (usually `python3-tk`) and run this app again."
    )


def _attempt_tkinter_install() -> None:
    commands: list[list[str]] = [
        [sys.executable, "-m", "pip", "install", "--user", "tk"],
    ]
    if sys.platform.startswith("win"):
        commands.append([sys.executable, "-m", "pip", "install", "tk"])

    for command in commands:
        try:
            subprocess.run(
                command,
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=180,
            )
        except (OSError, subprocess.SubprocessError):
            continue


def _import_tkinter_modules() -> tuple[Any, Any, Any, Any, Any]:
    try:
        tk_module = importlib.import_module("tkinter")
        tkfont_module = importlib.import_module("tkinter.font")
        filedialog_module = importlib.import_module("tkinter.filedialog")
        messagebox_module = importlib.import_module("tkinter.messagebox")
        ttk_module = importlib.import_module("tkinter.ttk")
        return tk_module, tkfont_module, filedialog_module, messagebox_module, ttk_module
    except ModuleNotFoundError:
        _attempt_tkinter_install()

    try:
        tk_module = importlib.import_module("tkinter")
        tkfont_module = importlib.import_module("tkinter.font")
        filedialog_module = importlib.import_module("tkinter.filedialog")
        messagebox_module = importlib.import_module("tkinter.messagebox")
        ttk_module = importlib.import_module("tkinter.ttk")
        return tk_module, tkfont_module, filedialog_module, messagebox_module, ttk_module
    except ModuleNotFoundError as exc:
        raise RuntimeError(_tk_install_help()) from exc


try:
    tk, tkfont, filedialog, messagebox, ttk = _import_tkinter_modules()
except RuntimeError as exc:
    print(str(exc), file=sys.stderr)
    raise SystemExit(1) from exc

APP_NAME = "Printer Supply & Tray Monitor"
APP_SLUG = "printer_supply_tray_monitor"
APP_CREDITS = "Credits: Jack Shetterly"
APP_ICON_FILE = "PrinterSupplyTrayMonitor-256.png"
DEFAULT_URL = ""
STATE_FILENAME = "printer_monitor_state.json"
DEFAULT_INTERVAL_MINUTES = 5
MAX_EVENTS = 20000

COLOR_MAP = {
    "k": "Black",
    "c": "Cyan",
    "m": "Magenta",
    "y": "Yellow",
}

SERVICE_DESK_PATTEE = "Pattee Library Service Desk"
SERVICE_DESK_POLLOCK = "Pollock Service Desk"
SERVICE_DESK_FINDLAY = "Findlay Service Desk"

LOCATION_OPTIONS = ["All", SERVICE_DESK_PATTEE, SERVICE_DESK_POLLOCK, SERVICE_DESK_FINDLAY]

PRINTER_SERVICE_DESK = {
    "03113": SERVICE_DESK_PATTEE,
    "03352": SERVICE_DESK_PATTEE,
    "03180": SERVICE_DESK_PATTEE,
    "03105": SERVICE_DESK_PATTEE,
    "03197": SERVICE_DESK_PATTEE,
    "03195": SERVICE_DESK_PATTEE,
    "03347": SERVICE_DESK_PATTEE,
    "03396": SERVICE_DESK_PATTEE,
    "03194": SERVICE_DESK_PATTEE,
    "03404": SERVICE_DESK_PATTEE,
    "03185": SERVICE_DESK_PATTEE,
    "03186": SERVICE_DESK_PATTEE,
    "03187": SERVICE_DESK_PATTEE,
    "03108": SERVICE_DESK_PATTEE,
    "03055": SERVICE_DESK_PATTEE,
    "03096": SERVICE_DESK_PATTEE,
    "03357": SERVICE_DESK_PATTEE,
    "03189": SERVICE_DESK_PATTEE,
    "03188": SERVICE_DESK_PATTEE,
    "03106": SERVICE_DESK_PATTEE,
    "03183": SERVICE_DESK_PATTEE,
    "03182": SERVICE_DESK_PATTEE,
    "03097": SERVICE_DESK_PATTEE,
    "03196": SERVICE_DESK_PATTEE,
    "03098": SERVICE_DESK_PATTEE,
    "03099": SERVICE_DESK_PATTEE,
    "03053": SERVICE_DESK_PATTEE,
    "03100": SERVICE_DESK_PATTEE,
    "03054": SERVICE_DESK_PATTEE,
    "03461": SERVICE_DESK_PATTEE,
    "03181": SERVICE_DESK_PATTEE,
    "03095": SERVICE_DESK_PATTEE,
    "03052": SERVICE_DESK_PATTEE,
    "03193": SERVICE_DESK_PATTEE,
    "03271": SERVICE_DESK_PATTEE,
    "03351": SERVICE_DESK_PATTEE,
    "03060": SERVICE_DESK_PATTEE,
    "03111": SERVICE_DESK_POLLOCK,
    "03110": SERVICE_DESK_POLLOCK,
    "03056": SERVICE_DESK_POLLOCK,
    "03107": SERVICE_DESK_POLLOCK,
    "03058": SERVICE_DESK_POLLOCK,
    "03112": SERVICE_DESK_POLLOCK,
    "03057": SERVICE_DESK_POLLOCK,
    "03109": SERVICE_DESK_POLLOCK,
    "03191": SERVICE_DESK_FINDLAY,
    "03190": SERVICE_DESK_FINDLAY,
    "03074": SERVICE_DESK_FINDLAY,
    "03050": SERVICE_DESK_FINDLAY,
    "03395": SERVICE_DESK_FINDLAY,
    "03114": SERVICE_DESK_FINDLAY,
    "03059": SERVICE_DESK_FINDLAY,
    "03192": SERVICE_DESK_FINDLAY,
    "03051": SERVICE_DESK_FINDLAY,
}

LOCATION_KEYWORDS = {
    SERVICE_DESK_PATTEE: [
        "atherton",
        "carnegie",
        "chambers",
        "davey",
        "deike",
        "ecore",
        "electrical engineering west",
        "hammond",
        "henderson",
        "hub",
        "leonhard",
        "life sciences",
        "nursing sciences",
        "osmond",
        "paterno",
        "pattee",
        "reber",
        "stuckeman",
        "waring",
        "westgate",
        "weston",
        "willard",
    ],
    SERVICE_DESK_POLLOCK: [
        "beaver",
        "pollock",
        "redifer",
        "thomas",
    ],
    SERVICE_DESK_FINDLAY: [
        "ag sciences",
        "business",
        "katz",
        "findlay",
        "warnock",
    ],
}

LEGACY_LOCATION_MAP = {
    "Pattee": SERVICE_DESK_PATTEE,
    "Pollock": SERVICE_DESK_POLLOCK,
    "Findlay": SERVICE_DESK_FINDLAY,
}

PRINTER_JOKES = [
    "Printer {printer_id} ({location}) needed {tray}. It was emptier than the break room fridge on Friday.",
    "Checked printer {printer_id} in {location}: {tray} was empty and morale dropped by 12%.",
    "Printer {printer_id} ({location}) asked for {tray}. I brought paper and emotional support.",
    "Tray check complete for printer {printer_id}: {tray} was empty, but optimism remains fully stocked.",
]

CS_MAJOR_JOKES = [
    "Printer {printer_id} in {location} ran out of {tray}. A CS major said they would refill it after one more compile.",
    "Checked {tray} on printer {printer_id}: empty. A CS major suggested turning it off and on before adding paper.",
    "Printer {printer_id} ({location}) had an empty {tray}. A CS major filed a bug report against the laws of physics.",
]

RED_ALERT_MAX = 1
YELLOW_ALERT_MIN = 2
YELLOW_ALERT_MAX = 15
ALERT_ORDER = {"Red": 0, "Yellow": 1}
DOWN_PATTERNS = [
    r"\bprinter\s+down\b",
    r"\bdevice\s+down\b",
    r"\bdown\b",
    r"\boffline\b",
    r"\bunreachable\b",
    r"\bnot\s+responding\b",
    r"\bout\s+of\s+service\b",
    r"\bcommunication\s+error\b",
    r"\bnetwork\s+error\b",
]


def get_app_data_dir() -> Path:
    candidates: list[Path] = []

    if sys.platform == "darwin":
        candidates.append(Path.home() / "Library" / "Application Support")
    elif sys.platform.startswith("win"):
        appdata = os.getenv("APPDATA")
        if appdata:
            candidates.append(Path(appdata))
        else:
            candidates.append(Path.home() / "AppData" / "Roaming")
    else:
        candidates.append(Path(os.getenv("XDG_DATA_HOME", str(Path.home() / ".local" / "share"))))

    # Always include a local fallback for restricted environments.
    candidates.append(Path(__file__).resolve().parent)

    for base_dir in candidates:
        app_dir = base_dir / APP_SLUG
        try:
            app_dir.mkdir(parents=True, exist_ok=True)
            return app_dir
        except OSError:
            continue

    raise OSError("Unable to create an application data directory.")


def now_iso() -> str:
    return datetime.now().astimezone().replace(microsecond=0).isoformat()


def parse_iso(value: str) -> datetime | None:
    try:
        return datetime.fromisoformat(value)
    except (TypeError, ValueError):
        return None


def display_time(value: str) -> str:
    dt = parse_iso(value)
    if dt is None:
        return value or "-"
    return dt.astimezone().strftime("%Y-%m-%d %H:%M:%S")


def _normalize_text_blob(*values: str) -> str:
    text = " ".join(value for value in values if value)
    return f" {re.sub(r'[^a-z0-9]+', ' ', text.lower()).strip()} "


def normalize_service_desk(value: str) -> str:
    clean = value.strip()
    if clean in LEGACY_LOCATION_MAP:
        return LEGACY_LOCATION_MAP[clean]
    return clean


def classify_location(*values: str, printer_id: str = "") -> str:
    normalized_id = re.sub(r"\D", "", printer_id or "")
    if normalized_id in PRINTER_SERVICE_DESK:
        return PRINTER_SERVICE_DESK[normalized_id]

    blob = _normalize_text_blob(*values)
    for location in [SERVICE_DESK_PATTEE, SERVICE_DESK_POLLOCK, SERVICE_DESK_FINDLAY]:
        for keyword in LOCATION_KEYWORDS[location]:
            token = f" {re.sub(r'[^a-z0-9]+', ' ', keyword.lower()).strip()} "
            if token in blob:
                return location
    # Fallback keeps every record mapped to one of the three service desks.
    return SERVICE_DESK_PATTEE


def classify_numeric_alert(level: int) -> str | None:
    if level <= RED_ALERT_MAX:
        return "Red"
    if YELLOW_ALERT_MIN <= level <= YELLOW_ALERT_MAX:
        return "Yellow"
    return None


def status_reports_down(status_blob: str) -> bool:
    for pattern in DOWN_PATTERNS:
        if re.search(pattern, status_blob, flags=re.IGNORECASE):
            return True
    return False


def detect_status_color_channels(status_blob: str) -> list[str]:
    channel_patterns = {
        "k": [r"\bblack\b", r"\bk\s*(?:toner|ink|drum)\b", r"\b(?:toner|ink|drum)\s*k\b"],
        "c": [r"\bcyan\b", r"\bc\s*(?:toner|ink|drum)\b", r"\b(?:toner|ink|drum)\s*c\b"],
        "m": [r"\bmagenta\b", r"\bm\s*(?:toner|ink|drum)\b", r"\b(?:toner|ink|drum)\s*m\b"],
        "y": [r"\byellow\b", r"\by\s*(?:toner|ink|drum)\b", r"\b(?:toner|ink|drum)\s*y\b"],
    }
    channels: list[str] = []
    for channel, patterns in channel_patterns.items():
        if any(re.search(pattern, status_blob, flags=re.IGNORECASE) for pattern in patterns):
            channels.append(channel)
    return channels


class NotificationManager:
    def __init__(self) -> None:
        self.platform = sys.platform

    def send(self, title: str, message: str) -> bool:
        try:
            if self.platform == "darwin":
                return self._send_macos(title, message)
            if self.platform.startswith("win"):
                return self._send_windows(title, message)
            return self._send_linux(title, message)
        except OSError:
            return False

    def _send_macos(self, title: str, message: str) -> bool:
        if not shutil.which("osascript"):
            return False
        safe_title = title.replace("\\", "\\\\").replace('"', '\\"')
        safe_message = message.replace("\\", "\\\\").replace('"', '\\"')
        script = f'display notification "{safe_message}" with title "{safe_title}"'
        subprocess.Popen(
            ["osascript", "-e", script],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return True

    def _send_linux(self, title: str, message: str) -> bool:
        if not shutil.which("notify-send"):
            return False
        subprocess.Popen(
            ["notify-send", title, message],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return True

    def _send_windows(self, title: str, message: str) -> bool:
        shell = shutil.which("powershell") or shutil.which("pwsh")
        if not shell:
            return False
        safe_title = title.replace("'", "''")
        safe_message = message.replace("'", "''")
        script = (
            "Add-Type -AssemblyName System.Windows.Forms; "
            "Add-Type -AssemblyName System.Drawing; "
            "$notify = New-Object System.Windows.Forms.NotifyIcon; "
            "$notify.Icon = [System.Drawing.SystemIcons]::Information; "
            f"$notify.BalloonTipTitle = '{safe_title}'; "
            f"$notify.BalloonTipText = '{safe_message}'; "
            "$notify.Visible = $true; "
            "$notify.ShowBalloonTip(5000); "
            "Start-Sleep -Milliseconds 5200; "
            "$notify.Dispose();"
        )
        subprocess.Popen(
            [shell, "-NoProfile", "-Command", script],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return True


@dataclass
class PrinterRecord:
    printer_id: str
    description: str = ""
    location: str = "Pattee"
    status_message: str = ""
    printer_text: str = ""
    device_last_update: str = ""
    row_tail: str = ""
    levels: dict[str, int] = field(default_factory=dict)
    empty_trays: list[str] = field(default_factory=list)


@dataclass
class LowAlert:
    printer_id: str
    description: str
    location: str
    item: str
    severity: str
    level: str
    source: str


class StateStore:
    def __init__(self, state_path: Path) -> None:
        self.state_path = state_path
        self.data: dict[str, Any] = {
            "open_empty_trays": {},
            "open_low_alerts": {},
            "events": [],
            "last_scan_at": "",
        }
        self.load()

    def load(self) -> None:
        if not self.state_path.exists():
            return
        try:
            self.data = json.loads(self.state_path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            self.data = {
                "open_empty_trays": {},
                "open_low_alerts": {},
                "events": [],
                "last_scan_at": "",
            }
            return

        if not isinstance(self.data, dict):
            self.data = {"open_empty_trays": {}, "open_low_alerts": {}, "events": [], "last_scan_at": ""}

        open_empties = self.data.get("open_empty_trays", {})
        if not isinstance(open_empties, dict):
            open_empties = {}
        normalized_open: dict[str, dict[str, str]] = {}
        for key, item in open_empties.items():
            if not isinstance(item, dict):
                continue
            item_copy = dict(item)
            item_copy.setdefault("key", key)
            normalized_location = normalize_service_desk(str(item_copy.get("location", "")))
            if normalized_location in LOCATION_OPTIONS[1:]:
                item_copy["location"] = normalized_location
            else:
                item_copy["location"] = classify_location(
                    str(item_copy.get("description", "")),
                    str(item_copy.get("status_message", "")),
                    str(item_copy.get("printer_text", "")),
                    printer_id=str(item_copy.get("printer_id", "")),
                )
            normalized_open[str(key)] = {k: str(v) for k, v in item_copy.items()}

        open_low_alerts = self.data.get("open_low_alerts", {})
        if not isinstance(open_low_alerts, dict):
            open_low_alerts = {}
        normalized_open_low: dict[str, dict[str, str]] = {}
        for key, item in open_low_alerts.items():
            if not isinstance(item, dict):
                continue
            item_copy = {str(k): str(v) for k, v in item.items()}
            item_copy.setdefault("key", str(key))
            item_copy.setdefault(
                "location",
                classify_location(
                    item_copy.get("description", ""),
                    item_copy.get("status_message", ""),
                    item_copy.get("printer_text", ""),
                    printer_id=item_copy.get("printer_id", ""),
                ),
            )
            item_copy.setdefault("item", item_copy.get("tray", ""))
            item_copy.setdefault("tray", item_copy.get("item", ""))
            normalized_open_low[str(key)] = item_copy

        events = self.data.get("events", [])
        if not isinstance(events, list):
            events = []
        normalized_events: list[dict[str, str]] = []
        for event in events:
            if not isinstance(event, dict):
                continue
            event_copy = {str(k): str(v) for k, v in event.items()}
            event_copy.setdefault("item", event_copy.get("tray", ""))
            event_copy.setdefault("severity", "")
            event_copy.setdefault("level", "")
            event_copy.setdefault("source", "")
            normalized_location = normalize_service_desk(event_copy.get("location", ""))
            if normalized_location in LOCATION_OPTIONS[1:]:
                event_copy["location"] = normalized_location
            else:
                event_copy["location"] = classify_location(
                    event_copy.get("description", ""),
                    event_copy.get("status_message", ""),
                    event_copy.get("printer_text", ""),
                    printer_id=event_copy.get("printer_id", ""),
                )
            normalized_events.append(event_copy)

        self.data = {
            "open_empty_trays": normalized_open,
            "open_low_alerts": normalized_open_low,
            "events": normalized_events,
            "last_scan_at": str(self.data.get("last_scan_at", "")),
        }

    def save(self) -> None:
        tmp_path = self.state_path.with_suffix(".tmp")
        tmp_path.write_text(json.dumps(self.data, indent=2), encoding="utf-8")
        tmp_path.replace(self.state_path)

    def get_open_empties(self) -> dict[str, dict[str, str]]:
        return dict(self.data.get("open_empty_trays", {}))

    def get_events(self) -> list[dict[str, str]]:
        return list(self.data.get("events", []))

    def get_last_scan(self) -> str:
        return str(self.data.get("last_scan_at", ""))

    def reconcile(
        self,
        current_empties: dict[str, dict[str, str]],
        current_low_alerts: list[LowAlert],
        scan_time: str,
    ) -> dict[str, int]:
        previous: dict[str, dict[str, str]] = self.data.get("open_empty_trays", {})
        previous_low: dict[str, dict[str, str]] = self.data.get("open_low_alerts", {})
        open_after: dict[str, dict[str, str]] = {}
        open_low_after: dict[str, dict[str, str]] = {}
        added = 0
        filled = 0
        low_opened = 0
        low_resolved = 0

        for key, item in current_empties.items():
            prior = previous.get(key)
            if prior is None:
                item["since"] = scan_time
                item["last_seen"] = scan_time
                open_after[key] = item
                self._append_event(scan_time, "empty", item, "detected by monitor")
                added += 1
            else:
                item["since"] = prior.get("since", scan_time)
                item["last_seen"] = scan_time
                open_after[key] = item

        for key, prior in previous.items():
            if key not in current_empties:
                resolved_item = dict(prior)
                resolved_item["last_seen"] = scan_time
                self._append_event(scan_time, "filled", resolved_item, "no longer reported empty")
                filled += 1

        for alert in current_low_alerts:
            key = f"{alert.printer_id}::{alert.item}"
            item = {
                "key": key,
                "printer_id": alert.printer_id,
                "location": alert.location,
                "description": alert.description,
                "item": alert.item,
                "tray": alert.item,
                "severity": alert.severity,
                "level": alert.level,
                "source": alert.source,
            }
            prior = previous_low.get(key)
            if prior is None:
                item["since"] = scan_time
                item["last_seen"] = scan_time
                open_low_after[key] = item
                self._append_event(
                    scan_time,
                    "low_open",
                    item,
                    f"{alert.severity} {alert.item} alert detected ({alert.level})",
                )
                low_opened += 1
            else:
                item["since"] = prior.get("since", scan_time)
                item["last_seen"] = scan_time
                open_low_after[key] = item
                if prior.get("severity") != alert.severity or prior.get("level") != alert.level:
                    self._append_event(
                        scan_time,
                        "low_update",
                        item,
                        f"alert updated to {alert.severity} ({alert.level})",
                    )

        for key, prior in previous_low.items():
            if key not in open_low_after:
                resolved_item = dict(prior)
                resolved_item["last_seen"] = scan_time
                self._append_event(
                    scan_time,
                    "low_resolved",
                    resolved_item,
                    f"{resolved_item.get('item', resolved_item.get('tray', 'low alert'))} no longer reported",
                )
                low_resolved += 1

        self.data["open_empty_trays"] = open_after
        self.data["open_low_alerts"] = open_low_after
        self.data["last_scan_at"] = scan_time
        self._trim_events()
        self.save()
        return {
            "new_empties": added,
            "new_filled": filled,
            "new_low_alerts": low_opened,
            "resolved_low_alerts": low_resolved,
        }

    def manual_mark_filled(self, tray_key: str, timestamp: str) -> bool:
        current = self.data.get("open_empty_trays", {})
        item = current.pop(tray_key, None)
        if item is None:
            return False

        item = dict(item)
        item["last_seen"] = timestamp
        self._append_event(timestamp, "filled", item, "manually marked filled")
        self.data["open_empty_trays"] = current
        self.data["last_scan_at"] = timestamp
        self._trim_events()
        self.save()
        return True

    def _append_event(self, timestamp: str, event_type: str, item: dict[str, str], note: str) -> None:
        event = {
            "timestamp": timestamp,
            "event_type": event_type,
            "printer_id": item.get("printer_id", ""),
            "location": item.get(
                "location",
                classify_location(
                    item.get("description", ""),
                    item.get("status_message", ""),
                    item.get("printer_text", ""),
                    printer_id=item.get("printer_id", ""),
                ),
            ),
            "description": item.get("description", ""),
            "item": item.get("item", item.get("tray", "")),
            "tray": item.get("tray", ""),
            "severity": item.get("severity", ""),
            "level": item.get("level", ""),
            "source": item.get("source", ""),
            "empty_since": item.get("since", ""),
            "last_seen": item.get("last_seen", ""),
            "status_message": item.get("status_message", ""),
            "printer_text": item.get("printer_text", ""),
            "note": note,
        }
        self.data.setdefault("events", []).append(event)

    def _trim_events(self) -> None:
        events = self.data.setdefault("events", [])
        if len(events) > MAX_EVENTS:
            self.data["events"] = events[-MAX_EVENTS:]


def fetch_html(url: str, timeout_seconds: int = 25) -> str:
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X) AppleWebKit/537.36 "
            "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
        },
    )
    with urllib.request.urlopen(request, timeout=timeout_seconds) as response:
        raw = response.read()
        charset = response.headers.get_content_charset() or "utf-8"
    return raw.decode(charset, errors="replace")


def html_to_lines(html: str) -> list[str]:
    cleaned = re.sub(r"(?is)<(script|style)[^>]*>.*?</\1>", " ", html)
    cleaned = re.sub(r"(?i)<br\s*/?>", "\n", cleaned)
    cleaned = re.sub(r"(?i)</(p|div|tr|td|th|li|h1|h2|h3|h4|h5|h6)>", "\n", cleaned)
    cleaned = re.sub(r"(?i)<[^>]+>", " ", cleaned)
    cleaned = unescape(cleaned)

    lines: list[str] = []
    for line in cleaned.splitlines():
        compact = re.sub(r"\s+", " ", line).strip()
        if compact:
            lines.append(compact)
    return lines


def parse_tail_metrics(row_tail: str) -> tuple[dict[str, int], str]:
    levels: dict[str, int] = {}
    last_update = ""

    time_match = re.search(r"\b(\d{2}/\d{2}/\d{2}\s+\d{2}:\d{2}:\d{2})\b", row_tail)
    if time_match:
        last_update = time_match.group(1)

    numbers = [int(value) for value in re.findall(r"\b(\d{1,3})\b", row_tail)]
    if len(numbers) >= 10:
        candidate = numbers[-10:]
        if all(0 <= value <= 100 for value in candidate):
            keys = [
                "toner_k",
                "toner_c",
                "toner_m",
                "toner_y",
                "drum_k",
                "drum_c",
                "drum_m",
                "drum_y",
                "belt",
                "fuser",
            ]
            levels = dict(zip(keys, candidate))

    return levels, last_update


def normalize_tray(value: str) -> str:
    token = re.sub(r"[^A-Za-z0-9-]", "", value).upper()
    if not token:
        return "Unknown Tray"
    if token.isdigit():
        return f"Tray {int(token)}"
    if token.startswith("TRAY"):
        token = token[4:] or "UNKNOWN"
        if token.isdigit():
            return f"Tray {int(token)}"
    return f"Tray {token}"


def detect_empty_trays(text: str) -> list[str]:
    trays: set[str] = set()

    patterns = [
        r"\btray\s*([A-Za-z0-9-]+)\s*(?:is\s*)?(?:empty|out|no\s+paper)\b",
        r"\bpaper\s*out\s*(?:in\s*)?tray\s*([A-Za-z0-9-]+)\b",
        r"\b(?:empty|out)\s*tray\s*([A-Za-z0-9-]+)\b",
    ]

    for pattern in patterns:
        for match in re.finditer(pattern, text, flags=re.IGNORECASE):
            trays.add(normalize_tray(match.group(1)))

    if not trays and re.search(r"\b(paper out|tray empty)\b", text, flags=re.IGNORECASE):
        trays.add("Unknown Tray")

    return sorted(trays)


def parse_monitor_page(html: str) -> list[PrinterRecord]:
    lines = html_to_lines(html)
    records: list[PrinterRecord] = []
    current: PrinterRecord | None = None

    id_pattern = re.compile(r"^(\d{5})\b(.*)$")

    for line in lines:
        id_match = id_pattern.match(line)
        if id_match:
            if current is not None:
                finalize_record(current)
                records.append(current)

            printer_id = id_match.group(1)
            tail = id_match.group(2).strip()
            levels, last_update = parse_tail_metrics(tail)
            current = PrinterRecord(
                printer_id=printer_id,
                row_tail=tail,
                levels=levels,
                device_last_update=last_update,
            )
            continue

        if current is None:
            continue

        lowered = line.lower()
        if lowered.startswith("description:"):
            current.description = line.split(":", 1)[1].strip()
        elif lowered.startswith("status message:"):
            current.status_message = line.split(":", 1)[1].strip()
        elif lowered.startswith("printer text:"):
            current.printer_text = line.split(":", 1)[1].strip()
        elif lowered.startswith("fuser:"):
            fuser_match = re.search(r"fuser:\s*(\d{1,3})%", line, flags=re.IGNORECASE)
            belt_match = re.search(r"belt:\s*(\d{1,3})%", line, flags=re.IGNORECASE)
            if fuser_match:
                current.levels["fuser"] = int(fuser_match.group(1))
            if belt_match:
                current.levels["belt"] = int(belt_match.group(1))

    if current is not None:
        finalize_record(current)
        records.append(current)

    # Guard against false positives from page chrome text.
    records = [record for record in records if record.printer_id.isdigit()]
    return records


def finalize_record(record: PrinterRecord) -> None:
    if not record.description:
        description_guess = re.split(
            r"\b\d{2}/\d{2}/\d{2}\s+\d{2}:\d{2}:\d{2}\b",
            record.row_tail,
            maxsplit=1,
        )[0].strip()
        record.description = description_guess or f"Printer {record.printer_id}"

    record.location = classify_location(
        record.description,
        record.status_message,
        record.printer_text,
        record.row_tail,
        printer_id=record.printer_id,
    )

    combined_text = " ".join(
        value
        for value in [record.status_message, record.printer_text, record.row_tail]
        if value and value.lower() not in {"none", "n/a"}
    )
    record.empty_trays = detect_empty_trays(combined_text)


def build_low_alerts(records: list[PrinterRecord]) -> list[LowAlert]:
    alerts: list[LowAlert] = []
    seen: set[tuple[str, str, str, str]] = set()

    def append_alert(record: PrinterRecord, item: str, severity: str, level: str, source: str) -> None:
        dedupe = (record.printer_id, item, severity, source)
        if dedupe in seen:
            return
        alerts.append(
            LowAlert(
                printer_id=record.printer_id,
                description=record.description,
                location=record.location,
                item=item,
                severity=severity,
                level=level,
                source=source,
            )
        )
        seen.add(dedupe)

    for record in records:
        status_blob_raw = f"{record.status_message} {record.printer_text}".strip()
        status_blob = _normalize_text_blob(status_blob_raw)

        def append_color_family_from_levels(prefix: str, label: str, source: str) -> set[str]:
            alerted_channels: set[str] = set()
            for channel in ["k", "c", "m", "y"]:
                level = record.levels.get(f"{prefix}_{channel}")
                if level is None:
                    continue
                severity = classify_numeric_alert(level)
                if not severity:
                    continue
                append_alert(
                    record=record,
                    item=f"{COLOR_MAP[channel]} {label}",
                    severity=severity,
                    level=f"{level}%",
                    source=source,
                )
                alerted_channels.add(channel)
            return alerted_channels

        toner_alerted_channels = append_color_family_from_levels(
            "toner",
            "Toner/Ink",
            "level-based toner/ink alert",
        )
        drum_alerted_channels = append_color_family_from_levels(
            "drum",
            "Drum",
            "level-based drum alert",
        )

        fuser = record.levels.get("fuser")
        if fuser is not None and fuser == 0:
            append_alert(
                record=record,
                item="Fuser",
                severity="Red",
                level=f"{fuser}%",
                source="critical alert from fuser level at 0",
            )

        belt = record.levels.get("belt")
        if belt is not None and belt == 0:
            append_alert(
                record=record,
                item="Transfer Belt",
                severity="Red",
                level=f"{belt}%",
                source="critical alert from belt level at 0",
            )

        if status_reports_down(status_blob):
            append_alert(
                record=record,
                item="Printer Down",
                severity="Red",
                level="DOWN",
                source="status text reports offline/down condition",
            )

        toner_status_severity: str | None = None
        if re.search(r"\bred alert\b.*\b(toner|ink)\b|\b(toner|ink)\b.*\bred alert\b", status_blob):
            toner_status_severity = "Red"
        elif re.search(r"\byellow alert\b.*\b(toner|ink)\b|\b(toner|ink)\b.*\byellow alert\b", status_blob):
            toner_status_severity = "Yellow"
        elif re.search(r"\blow toner\b|\blow ink\b", status_blob):
            toner_status_severity = "Yellow"
        if toner_status_severity:
            status_channels = detect_status_color_channels(status_blob)
            if status_channels:
                for channel in status_channels:
                    if channel in toner_alerted_channels:
                        continue
                    append_alert(
                        record=record,
                        item=f"{COLOR_MAP[channel]} Toner/Ink",
                        severity=toner_status_severity,
                        level="reported",
                        source=f"status reports {toner_status_severity.lower()} toner/ink alert",
                    )
            elif not toner_alerted_channels:
                append_alert(
                    record=record,
                    item="Toner/Ink",
                    severity=toner_status_severity,
                    level="reported",
                    source=f"status reports {toner_status_severity.lower()} toner/ink alert",
                )

        drum_status_severity: str | None = None
        if re.search(r"\bred alert\b.*\bdrum\b|\bdrum\b.*\bred alert\b|\breplace drum\b", status_blob):
            drum_status_severity = "Red"
        elif re.search(r"\byellow alert\b.*\bdrum\b|\bdrum\b.*\byellow alert\b|\blow drum\b", status_blob):
            drum_status_severity = "Yellow"
        if drum_status_severity:
            status_channels = detect_status_color_channels(status_blob)
            if status_channels:
                for channel in status_channels:
                    if channel in drum_alerted_channels:
                        continue
                    append_alert(
                        record=record,
                        item=f"{COLOR_MAP[channel]} Drum",
                        severity=drum_status_severity,
                        level="reported",
                        source=f"status reports {drum_status_severity.lower()} drum alert",
                    )
            elif not drum_alerted_channels:
                append_alert(
                    record=record,
                    item="Drum",
                    severity=drum_status_severity,
                    level="reported",
                    source=f"status reports {drum_status_severity.lower()} drum alert",
                )

    return sorted(
        alerts,
        key=lambda alert: (alert.location, ALERT_ORDER.get(alert.severity, 99), alert.printer_id, alert.item),
    )


def build_current_empties(records: list[PrinterRecord]) -> dict[str, dict[str, str]]:
    empties: dict[str, dict[str, str]] = {}

    for record in records:
        for tray in record.empty_trays:
            key = f"{record.printer_id}::{tray}"
            empties[key] = {
                "key": key,
                "printer_id": record.printer_id,
                "location": record.location,
                "description": record.description,
                "tray": tray,
                "status_message": record.status_message,
                "printer_text": record.printer_text,
                "device_last_update": record.device_last_update,
            }

    return empties


class PrinterMonitorApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title(APP_NAME)
        self._window_icon = None
        self._apply_window_icon()
        self.root.geometry("1500x920")
        self.root.minsize(1180, 760)
        self.root.resizable(True, True)

        self.app_data_dir = get_app_data_dir()
        self.state_store = StateStore(self.app_data_dir / STATE_FILENAME)
        self.state_lock = threading.Lock()

        self.url_var = tk.StringVar(value=DEFAULT_URL)
        self.auto_refresh_var = tk.BooleanVar(value=False)
        self.notifications_enabled_var = tk.BooleanVar(value=True)
        self.refresh_interval_var = tk.IntVar(value=DEFAULT_INTERVAL_MINUTES)
        self.location_filter_var = tk.StringVar(value="All")
        self.worknote_mode_var = tk.StringVar(value="Detected Empty")

        self.status_var = tk.StringVar(value="Ready")
        self.last_refresh_var = tk.StringVar(value="Never")
        self.summary_printer_var = tk.StringVar(value="0")
        self.summary_low_var = tk.StringVar(value="0")
        self.summary_empty_var = tk.StringVar(value="0")

        self.records: list[PrinterRecord] = []
        self.low_alerts: list[LowAlert] = []
        self.low_alert_lookup: dict[str, LowAlert] = {}
        self.open_empties: dict[str, dict[str, str]] = self.state_store.get_open_empties()
        self.events: list[dict[str, str]] = self.state_store.get_events()
        self.notification_manager = NotificationManager()
        self.joke_tray_key = ""
        self.active_alert_source = "empty"

        self.refresh_in_progress = False
        self.next_auto_refresh_epoch = 0.0

        self._build_styles()
        self._build_menu_bar()
        self._build_ui()
        self._update_summary_counts()
        self._update_menu_summary()
        self._refresh_history_tree()
        self._refresh_empty_tree()

        saved_scan = self.state_store.get_last_scan()
        if saved_scan:
            self.last_refresh_var.set(display_time(saved_scan))

        self.trigger_refresh()
        self.root.after(1000, self._auto_refresh_tick)

    def _build_styles(self) -> None:
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        families = set(tkfont.families())
        if "SF Pro Text" in families:
            self.font_family = "SF Pro Text"
        elif "Helvetica Neue" in families:
            self.font_family = "Helvetica Neue"
        else:
            self.font_family = "Helvetica"

        if "SF Pro Display" in families:
            self.display_font_family = "SF Pro Display"
        else:
            self.display_font_family = self.font_family

        self.colors = {
            "window_bg": "#151a16",
            "chrome_bg": "#1d231e",
            "surface": "#242b25",
            "surface_soft": "#212721",
            "surface_raised": "#2a322b",
            "border": "#3a433b",
            "border_soft": "#303830",
            "title": "#f3f5f1",
            "text": "#d2d8d0",
            "muted": "#98a396",
            "accent": "#0a84ff",
            "accent_active": "#2f96ff",
            "accent_pressed": "#0070e8",
            "accent_soft": "#233140",
            "table_header": "#2d352e",
            "table_alt": "#283027",
            "selection": "#32465c",
            "footer_bg": "#1b201b",
            "footer_text": "#879182",
        }

        self.root.configure(bg=self.colors["window_bg"])
        style.configure(".", background=self.colors["window_bg"], foreground=self.colors["text"], font=(self.font_family, 11))

        style.configure("App.TFrame", background=self.colors["window_bg"])
        style.configure("Chrome.TFrame", background=self.colors["chrome_bg"], relief="flat")
        style.configure("Toolbar.TFrame", background=self.colors["chrome_bg"], relief="flat")
        style.configure("SummaryCard.TFrame", background=self.colors["surface"], relief="flat")
        style.configure("Card.TFrame", background=self.colors["surface"], relief="flat")
        style.configure("Surface.TFrame", background=self.colors["surface"], relief="flat")

        style.configure(
            "Title.TLabel",
            background=self.colors["chrome_bg"],
            foreground=self.colors["title"],
            font=(self.display_font_family, 20, "bold"),
        )
        style.configure(
            "Subtitle.TLabel",
            background=self.colors["chrome_bg"],
            foreground=self.colors["muted"],
            font=(self.font_family, 11),
        )
        style.configure(
            "Toolbar.TLabel",
            background=self.colors["chrome_bg"],
            foreground=self.colors["muted"],
            font=(self.font_family, 11, "bold"),
        )
        style.configure(
            "Value.TLabel",
            background=self.colors["chrome_bg"],
            foreground=self.colors["text"],
            font=(self.font_family, 11, "bold"),
        )
        style.configure(
            "SummaryTitle.TLabel",
            background=self.colors["surface"],
            foreground=self.colors["muted"],
            font=(self.font_family, 11, "bold"),
        )
        style.configure(
            "SummaryValue.TLabel",
            background=self.colors["surface"],
            foreground=self.colors["title"],
            font=(self.display_font_family, 31, "bold"),
        )
        style.configure(
            "SummaryHint.TLabel",
            background=self.colors["surface"],
            foreground=self.colors["muted"],
            font=(self.font_family, 10),
        )
        style.configure("HeroStatCard.TFrame", background=self.colors["surface"], relief="flat")
        style.configure(
            "HeroStatTitle.TLabel",
            background=self.colors["surface"],
            foreground=self.colors["muted"],
            font=(self.font_family, 10, "bold"),
        )
        style.configure(
            "HeroStatValue.TLabel",
            background=self.colors["surface"],
            foreground=self.colors["title"],
            font=(self.display_font_family, 24, "bold"),
        )

        style.configure(
            "Section.TLabelframe",
            background=self.colors["surface"],
            bordercolor=self.colors["border"],
            relief="flat",
            padding=12,
        )
        style.configure(
            "Section.TLabelframe.Label",
            background=self.colors["surface"],
            foreground=self.colors["title"],
            font=(self.font_family, 12, "bold"),
        )

        style.configure(
            "Field.TEntry",
            fieldbackground=self.colors["surface_raised"],
            foreground=self.colors["text"],
            borderwidth=1,
            relief="flat",
            padding=10,
        )
        style.map(
            "Field.TEntry",
            bordercolor=[("focus", self.colors["accent"])],
            lightcolor=[("focus", self.colors["accent"])],
            darkcolor=[("focus", self.colors["accent"])],
        )
        style.configure(
            "Field.TCombobox",
            fieldbackground=self.colors["surface_raised"],
            background=self.colors["surface_raised"],
            foreground=self.colors["text"],
            borderwidth=1,
            relief="flat",
            padding=7,
            arrowsize=14,
        )
        style.map(
            "Field.TCombobox",
            fieldbackground=[("readonly", self.colors["surface_raised"])],
            background=[("readonly", self.colors["surface_raised"])],
            bordercolor=[("focus", self.colors["accent"])],
            lightcolor=[("focus", self.colors["accent"])],
            darkcolor=[("focus", self.colors["accent"])],
        )
        style.configure(
            "Field.TSpinbox",
            fieldbackground=self.colors["surface_raised"],
            foreground=self.colors["text"],
            borderwidth=1,
            relief="flat",
            padding=6,
            arrowsize=12,
        )
        style.map(
            "Field.TSpinbox",
            bordercolor=[("focus", self.colors["accent"])],
            lightcolor=[("focus", self.colors["accent"])],
            darkcolor=[("focus", self.colors["accent"])],
        )

        style.configure(
            "PrimaryDark.TButton",
            font=(self.font_family, 11, "bold"),
            padding=(16, 9),
            foreground="#ffffff",
            background=self.colors["accent"],
            borderwidth=0,
            relief="flat",
        )
        style.map(
            "PrimaryDark.TButton",
            background=[("pressed", self.colors["accent_pressed"]), ("active", self.colors["accent_active"])],
            foreground=[("disabled", "#e4ebf5")],
        )
        style.configure(
            "GhostDark.TButton",
            font=(self.font_family, 11, "bold"),
            padding=(14, 8),
            foreground=self.colors["text"],
            background=self.colors["surface_raised"],
            borderwidth=0,
            relief="flat",
        )
        style.map(
            "GhostDark.TButton",
            background=[("pressed", "#343f35"), ("active", "#313a33")],
            foreground=[("disabled", "#6c766c")],
        )
        style.configure(
            "Toolbar.TCheckbutton",
            background=self.colors["chrome_bg"],
            foreground=self.colors["text"],
            font=(self.font_family, 11),
        )

        style.configure(
            "Glass.TNotebook",
            background=self.colors["window_bg"],
            borderwidth=0,
            tabmargins=(0, 10, 0, 0),
        )
        style.configure(
            "Glass.TNotebook.Tab",
            font=(self.font_family, 11, "bold"),
            padding=(20, 10),
            background=self.colors["surface_soft"],
            foreground=self.colors["muted"],
            borderwidth=0,
        )
        style.map(
            "Glass.TNotebook.Tab",
            background=[("selected", self.colors["surface_raised"]), ("active", "#2d352f")],
            foreground=[("selected", self.colors["title"]), ("active", self.colors["title"])],
        )

        style.configure(
            "Data.Treeview",
            background=self.colors["surface"],
            fieldbackground=self.colors["surface"],
            foreground=self.colors["text"],
            borderwidth=0,
            relief="flat",
            rowheight=31,
            font=(self.font_family, 11),
        )
        style.configure(
            "Data.Treeview.Heading",
            background=self.colors["table_header"],
            foreground=self.colors["title"],
            borderwidth=0,
            relief="flat",
            padding=(10, 9),
            font=(self.font_family, 11, "bold"),
        )
        style.map(
            "Data.Treeview",
            background=[("selected", self.colors["selection"])],
            foreground=[("selected", self.colors["title"])],
        )
        style.map(
            "Data.Treeview.Heading",
            background=[("active", "#334038")],
        )

        style.configure(
            "TScrollbar",
            troughcolor=self.colors["surface_soft"],
            background="#475247",
            bordercolor=self.colors["surface_soft"],
            arrowcolor="#9ba79b",
            relief="flat",
        )

        style.configure(
            "Status.TLabel",
            background=self.colors["footer_bg"],
            foreground=self.colors["footer_text"],
            font=(self.font_family, 10),
            padding=(12, 9),
        )
        style.configure(
            "Credit.TLabel",
            background=self.colors["footer_bg"],
            foreground=self.colors["muted"],
            font=(self.font_family, 10, "bold"),
            padding=(12, 9),
        )

    def _build_ui(self) -> None:
        container = ttk.Frame(self.root, style="App.TFrame", padding=(24, 20, 24, 16))
        container.pack(fill="both", expand=True)
        container.columnconfigure(0, weight=1)
        container.rowconfigure(2, weight=1)

        hero = ttk.Frame(container, style="Chrome.TFrame", padding=(18, 12))
        hero.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        hero.columnconfigure(0, weight=1)
        ttk.Label(hero, text=APP_NAME, style="Title.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(hero, text="Operational view with live alerts and tray history", style="Subtitle.TLabel").grid(
            row=1, column=0, sticky="w", pady=(2, 0)
        )
        hero_stats = ttk.Frame(hero, style="Chrome.TFrame")
        hero_stats.grid(row=0, column=1, rowspan=2, sticky="e")
        for column in (0, 1, 2):
            hero_stats.columnconfigure(column, weight=1)
        self._build_hero_stat(hero_stats, 0, "Printers Seen", self.summary_printer_var)
        self._build_hero_stat(hero_stats, 1, "Low Supply Alerts", self.summary_low_var)
        self._build_hero_stat(hero_stats, 2, "Open Empty Trays", self.summary_empty_var)

        controls = ttk.Frame(container, style="Toolbar.TFrame", padding=(18, 14))
        controls.grid(row=1, column=0, sticky="ew", pady=(0, 12))
        controls.columnconfigure(1, weight=1)
        controls.columnconfigure(9, weight=1)

        ttk.Label(controls, text="Monitor URL", style="Toolbar.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Entry(controls, textvariable=self.url_var, style="Field.TEntry").grid(
            row=0, column=1, columnspan=3, sticky="ew", padx=(8, 10)
        )
        ttk.Button(controls, text="Refresh Now", command=self.trigger_refresh, style="PrimaryDark.TButton").grid(
            row=0, column=4, padx=(0, 10), sticky="e"
        )
        ttk.Checkbutton(
            controls,
            text="Auto Refresh",
            variable=self.auto_refresh_var,
            style="Toolbar.TCheckbutton",
        ).grid(row=0, column=5, sticky="w")
        ttk.Label(controls, text="Every (min)", style="Toolbar.TLabel").grid(row=0, column=6, sticky="e", padx=(10, 4))
        ttk.Spinbox(
            controls,
            from_=1,
            to=180,
            textvariable=self.refresh_interval_var,
            width=5,
            style="Field.TSpinbox",
        ).grid(row=0, column=7, sticky="w")
        ttk.Checkbutton(
            controls,
            text="Notifications",
            variable=self.notifications_enabled_var,
            style="Toolbar.TCheckbutton",
        ).grid(row=0, column=8, sticky="w", padx=(12, 0))

        ttk.Label(controls, text="Last Refresh", style="Toolbar.TLabel").grid(row=1, column=4, sticky="e", pady=(12, 0), padx=(0, 6))
        ttk.Label(controls, textvariable=self.last_refresh_var, style="Value.TLabel").grid(
            row=1, column=5, columnspan=3, sticky="w", pady=(12, 0)
        )

        ttk.Label(controls, text="Served By Filter", style="Toolbar.TLabel").grid(row=1, column=0, sticky="w", pady=(12, 0))
        location_filter = ttk.Combobox(
            controls,
            textvariable=self.location_filter_var,
            values=LOCATION_OPTIONS,
            width=30,
            state="readonly",
            style="Field.TCombobox",
        )
        location_filter.grid(row=1, column=1, sticky="w", pady=(12, 0))
        location_filter.bind("<<ComboboxSelected>>", lambda _event: self._on_location_filter_changed())
        ttk.Label(
            controls,
            text="Filter applies to dashboard, history, export, and ticket text.",
            style="Toolbar.TLabel",
        ).grid(row=1, column=2, columnspan=2, sticky="w", pady=(12, 0), padx=(8, 0))

        notebook = ttk.Notebook(container, style="Glass.TNotebook")
        notebook.grid(row=2, column=0, sticky="nsew")

        dashboard = ttk.Frame(notebook, style="App.TFrame", padding=(0, 10, 0, 0))
        history_tab = ttk.Frame(notebook, style="App.TFrame", padding=(0, 10, 0, 0))
        notebook.add(dashboard, text="Dashboard")
        notebook.add(history_tab, text="Alert History")

        dashboard.columnconfigure(0, weight=1)
        dashboard.rowconfigure(0, weight=1)
        dashboard_split = ttk.Panedwindow(dashboard, orient="vertical")
        dashboard_split.grid(row=0, column=0, sticky="nsew")

        top_split = ttk.Panedwindow(dashboard_split, orient="horizontal")
        top_container_left = ttk.Frame(top_split, style="App.TFrame")
        top_container_right = ttk.Frame(top_split, style="App.TFrame")
        top_split.add(top_container_left, weight=1)
        top_split.add(top_container_right, weight=1)
        dashboard_split.add(top_split, weight=3)

        worknote_host = ttk.Frame(dashboard_split, style="App.TFrame")
        worknote_host.columnconfigure(0, weight=1)
        worknote_host.rowconfigure(0, weight=1)
        dashboard_split.add(worknote_host, weight=2)

        low_frame = ttk.LabelFrame(top_container_left, text="Low Supplies", style="Section.TLabelframe")
        low_frame.grid(row=0, column=0, sticky="nsew", padx=(0, 6), pady=(0, 6))
        top_container_left.columnconfigure(0, weight=1)
        top_container_left.rowconfigure(0, weight=1)
        low_frame.columnconfigure(0, weight=1)
        low_frame.rowconfigure(0, weight=1)

        low_columns = ("printer_id", "location", "description", "item", "severity", "level", "source")
        self.low_tree = ttk.Treeview(low_frame, columns=low_columns, show="headings")
        for col, title, width in [
            ("printer_id", "Printer", 90),
            ("location", "Served By", 205),
            ("description", "Description", 220),
            ("item", "Item", 120),
            ("severity", "Alert", 90),
            ("level", "Level", 90),
            ("source", "Source", 200),
        ]:
            self.low_tree.heading(col, text=title)
            self.low_tree.column(col, width=width, minwidth=70, anchor="w", stretch=True)
        self.low_tree.grid(row=0, column=0, sticky="nsew")
        self.low_tree.bind("<<TreeviewSelect>>", self._on_low_tree_select)
        self.low_tree.bind("<Double-1>", self._open_selected_low_alert_report)
        self._add_scrollbar(low_frame, self.low_tree, row=0, column=1)

        empty_frame = ttk.LabelFrame(top_container_right, text="Current Empty Trays", style="Section.TLabelframe")
        empty_frame.grid(row=0, column=0, sticky="nsew", padx=(6, 0), pady=(0, 6))
        top_container_right.columnconfigure(0, weight=1)
        top_container_right.rowconfigure(0, weight=1)
        empty_frame.columnconfigure(0, weight=1)
        empty_frame.rowconfigure(0, weight=1)

        empty_columns = ("printer_id", "location", "description", "tray", "since", "last_seen")
        self.empty_tree = ttk.Treeview(empty_frame, columns=empty_columns, show="headings", selectmode="browse")
        for col, title, width in [
            ("printer_id", "Printer", 90),
            ("location", "Served By", 205),
            ("description", "Description", 220),
            ("tray", "Tray", 110),
            ("since", "Empty Since", 160),
            ("last_seen", "Last Seen", 160),
        ]:
            self.empty_tree.heading(col, text=title)
            self.empty_tree.column(col, width=width, minwidth=70, anchor="w", stretch=True)
        self.empty_tree.grid(row=0, column=0, sticky="nsew")
        self.empty_tree.bind("<<TreeviewSelect>>", self._on_empty_tree_select)
        self.empty_tree.bind("<Double-1>", self._open_selected_empty_alert_report)
        self._add_scrollbar(empty_frame, self.empty_tree, row=0, column=1)

        actions = ttk.Frame(empty_frame, style="Surface.TFrame")
        actions.grid(row=1, column=0, sticky="ew", pady=(8, 0))
        action_buttons = [
            ("Generate Worknote", self.generate_worknote),
            ("Copy Worknote", self.copy_worknote),
            ("Generate Description", self.generate_description),
            ("Copy Description", self.copy_description),
            ("Generate Joke", self.generate_joke),
            ("Copy Joke", self.copy_joke),
            ("Mark Filled (Manual)", self.mark_selected_filled),
        ]
        for idx, (label, command) in enumerate(action_buttons):
            actions.columnconfigure(idx, weight=1)
            ttk.Button(actions, text=label, command=command, style="GhostDark.TButton").grid(
                row=0,
                column=idx,
                sticky="ew",
                padx=(0 if idx == 0 else 8, 0),
            )

        worknote_frame = ttk.LabelFrame(worknote_host, text="ServiceNow Worknote Generator", style="Section.TLabelframe")
        worknote_frame.grid(row=0, column=0, sticky="nsew", pady=(6, 0))
        worknote_frame.columnconfigure(0, weight=1)
        worknote_frame.rowconfigure(1, weight=2)
        worknote_frame.rowconfigure(3, weight=1)
        worknote_frame.rowconfigure(5, weight=1)

        header = ttk.Frame(worknote_frame, style="Surface.TFrame")
        header.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        ttk.Label(header, text="Template", style="Toolbar.TLabel").pack(side="left")
        mode = ttk.Combobox(
            header,
            textvariable=self.worknote_mode_var,
            values=["Detected Empty", "Refilled and Tested"],
            width=24,
            state="readonly",
            style="Field.TCombobox",
        )
        mode.pack(side="left", padx=(6, 8))
        mode.bind("<<ComboboxSelected>>", lambda _event: self._populate_service_now_fields())

        self.worknote_text = tk.Text(
            worknote_frame,
            wrap="word",
            height=8,
            font=(self.font_family, 12),
            bg=self.colors["surface_raised"],
            fg=self.colors["text"],
            insertbackground=self.colors["title"],
            relief="flat",
            bd=0,
            highlightthickness=1,
            highlightbackground=self.colors["border"],
            highlightcolor=self.colors["accent"],
            padx=12,
            pady=10,
        )
        self.worknote_text.grid(row=1, column=0, sticky="nsew")

        ttk.Label(worknote_frame, text="ServiceNow Description", style="Toolbar.TLabel").grid(
            row=2, column=0, sticky="w", pady=(8, 4)
        )
        self.description_text = tk.Text(
            worknote_frame,
            wrap="word",
            height=5,
            font=(self.font_family, 11),
            bg=self.colors["surface_raised"],
            fg=self.colors["text"],
            insertbackground=self.colors["title"],
            relief="flat",
            bd=0,
            highlightthickness=1,
            highlightbackground=self.colors["border"],
            highlightcolor=self.colors["accent"],
            padx=12,
            pady=10,
        )
        self.description_text.grid(row=3, column=0, sticky="nsew")

        ttk.Label(worknote_frame, text="Printer Keys Chat Joke", style="Toolbar.TLabel").grid(
            row=4, column=0, sticky="w", pady=(8, 4)
        )
        self.joke_text = tk.Text(
            worknote_frame,
            wrap="word",
            height=3,
            font=(self.font_family, 11),
            bg=self.colors["surface_raised"],
            fg=self.colors["text"],
            insertbackground=self.colors["title"],
            relief="flat",
            bd=0,
            highlightthickness=1,
            highlightbackground=self.colors["border"],
            highlightcolor=self.colors["accent"],
            padx=12,
            pady=10,
        )
        self.joke_text.grid(row=5, column=0, sticky="nsew")

        history_tab.columnconfigure(0, weight=1)
        history_tab.rowconfigure(1, weight=1)

        history_actions = ttk.Frame(history_tab, style="App.TFrame")
        history_actions.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        ttk.Button(
            history_actions,
            text="Export Alert History CSV",
            command=self.export_history_csv,
            style="GhostDark.TButton",
        ).pack(side="left")

        history_columns = ("timestamp", "event_type", "printer_id", "location", "description", "item", "severity", "level", "note")
        self.history_tree = ttk.Treeview(history_tab, columns=history_columns, show="headings", style="Data.Treeview")
        for col, title, width in [
            ("timestamp", "Time", 170),
            ("event_type", "Event", 110),
            ("printer_id", "Printer", 90),
            ("location", "Served By", 195),
            ("description", "Description", 220),
            ("item", "Item/Tray", 140),
            ("severity", "Severity", 90),
            ("level", "Level", 90),
            ("note", "Note", 240),
        ]:
            self.history_tree.heading(col, text=title)
            self.history_tree.column(col, width=width, minwidth=70, anchor="w", stretch=True)
        self.history_tree.grid(row=1, column=0, sticky="nsew")
        self._add_scrollbar(history_tab, self.history_tree, row=1, column=1)

        for tree in (self.low_tree, self.empty_tree, self.history_tree):
            tree.configure(style="Data.Treeview")
            tree.tag_configure("evenrow", background=self.colors["surface"])
            tree.tag_configure("oddrow", background=self.colors["table_alt"])
        self.low_tree.tag_configure("redrow", background="#4d252d", foreground="#ffe3e8")
        self.low_tree.tag_configure("yellowrow", background="#4a4429", foreground="#fff4cc")

        footer = ttk.Frame(container, style="Chrome.TFrame")
        footer.grid(row=3, column=0, sticky="ew", pady=(10, 0))
        footer.columnconfigure(0, weight=1)

        ttk.Label(footer, textvariable=self.status_var, style="Status.TLabel", anchor="w").grid(
            row=0, column=0, sticky="ew"
        )
        ttk.Label(footer, text=APP_CREDITS, style="Credit.TLabel", anchor="e").grid(row=0, column=1, sticky="e")

    def _build_summary_card(self, parent: ttk.Frame, column: int, title: str, variable: tk.StringVar) -> None:
        card = ttk.Frame(parent, style="SummaryCard.TFrame", padding=(20, 16))
        card.grid(row=0, column=column, sticky="ew", padx=(0 if column == 0 else 8, 0))
        ttk.Label(card, text=title, style="SummaryTitle.TLabel").pack(anchor="w")
        ttk.Label(card, textvariable=variable, style="SummaryValue.TLabel").pack(anchor="w", pady=(6, 0))
        ttk.Label(card, text="Live", style="SummaryHint.TLabel").pack(anchor="w", pady=(2, 0))

    def _build_hero_stat(self, parent: ttk.Frame, column: int, title: str, variable: tk.StringVar) -> None:
        card = ttk.Frame(parent, style="HeroStatCard.TFrame", padding=(16, 8))
        card.grid(row=0, column=column, sticky="nsew", padx=(8 if column > 0 else 0, 0))
        ttk.Label(card, text=title, style="HeroStatTitle.TLabel").pack(anchor="w")
        ttk.Label(card, textvariable=variable, style="HeroStatValue.TLabel").pack(anchor="w", pady=(2, 0))

    def _add_scrollbar(self, parent: ttk.Widget, tree: ttk.Treeview, row: int, column: int) -> None:
        scrollbar = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scrollbar.set)
        scrollbar.grid(row=row, column=column, sticky="ns")

    def _build_menu_bar(self) -> None:
        self.menu_bar = tk.Menu(self.root)

        self.summary_menu = tk.Menu(self.menu_bar, tearoff=False)
        self.summary_menu.add_command(label="Served By Filter: All", state="disabled")
        self.summary_menu.add_command(label="Printers Seen: 0", state="disabled")
        self.summary_menu.add_command(label="Low Supply Alerts: 0", state="disabled")
        self.summary_menu.add_command(label="Open Empty Trays: 0", state="disabled")
        self.summary_menu.add_command(label="Last Refresh: Never", state="disabled")
        self.summary_menu.add_command(label="Status: Ready", state="disabled")

        self.actions_menu = tk.Menu(self.menu_bar, tearoff=False)
        self.actions_menu.add_command(label="Refresh Now", command=self.trigger_refresh)
        self.actions_menu.add_command(label="Generate ServiceNow Text", command=self._populate_service_now_fields)
        self.actions_menu.add_command(label="Generate Joke", command=self.generate_joke)
        self.actions_menu.add_separator()
        self.actions_menu.add_command(label="Copy Summary Snapshot", command=self.copy_summary_snapshot)
        self.actions_menu.add_separator()
        self.actions_menu.add_command(label="Quit", command=self.root.destroy)

        self.menu_bar.add_cascade(label="Summary", menu=self.summary_menu)
        self.menu_bar.add_cascade(label="Actions", menu=self.actions_menu)
        self.root.configure(menu=self.menu_bar)

    def _update_menu_summary(self) -> None:
        location = self.location_filter_var.get()
        self.summary_menu.entryconfigure(0, label=f"Served By Filter: {location}")
        self.summary_menu.entryconfigure(1, label=f"Printers Seen: {self.summary_printer_var.get()}")
        self.summary_menu.entryconfigure(2, label=f"Low Supply Alerts: {self.summary_low_var.get()}")
        self.summary_menu.entryconfigure(3, label=f"Open Empty Trays: {self.summary_empty_var.get()}")
        self.summary_menu.entryconfigure(4, label=f"Last Refresh: {self.last_refresh_var.get()}")
        self.summary_menu.entryconfigure(5, label=f"Status: {self.status_var.get()[:90]}")

    def _location_allows(self, location: str) -> bool:
        selected = self.location_filter_var.get()
        return selected == "All" or location == selected

    def _filtered_records(self) -> list[PrinterRecord]:
        return [record for record in self.records if self._location_allows(record.location)]

    def _filtered_low_alerts(self) -> list[LowAlert]:
        return [alert for alert in self.low_alerts if self._location_allows(alert.location)]

    def _filtered_open_empties(self) -> list[dict[str, str]]:
        rows: list[dict[str, str]] = []
        for row in self.open_empties.values():
            location = normalize_service_desk(row.get("location", "")) or classify_location(
                row.get("description", ""),
                row.get("status_message", ""),
                row.get("printer_text", ""),
                printer_id=row.get("printer_id", ""),
            )
            if self._location_allows(location):
                row["location"] = location
                rows.append(row)
        return rows

    def _filtered_events(self) -> list[dict[str, str]]:
        rows: list[dict[str, str]] = []
        for event in self.events:
            location = normalize_service_desk(event.get("location", "")) or classify_location(
                event.get("description", ""),
                event.get("status_message", ""),
                event.get("printer_text", ""),
                printer_id=event.get("printer_id", ""),
            )
            if self._location_allows(location):
                event["location"] = location
                rows.append(event)
        return rows

    def _update_summary_counts(self) -> None:
        self.summary_printer_var.set(str(len(self._filtered_records())))
        self.summary_low_var.set(str(len(self._filtered_low_alerts())))
        self.summary_empty_var.set(str(len(self._filtered_open_empties())))

    def _on_location_filter_changed(self) -> None:
        self._update_summary_counts()
        self._refresh_low_tree()
        self._refresh_empty_tree()
        self._refresh_history_tree()
        self._populate_service_now_fields()
        self.status_var.set(f"Served by filter set to {self.location_filter_var.get()}.")
        self._update_menu_summary()

    def _summary_snapshot_text(self) -> str:
        return (
            f"Served By Filter: {self.location_filter_var.get()}\n"
            f"Printers Seen: {self.summary_printer_var.get()}\n"
            f"Low Supply Alerts: {self.summary_low_var.get()}\n"
            f"Open Empty Trays: {self.summary_empty_var.get()}\n"
            f"Last Refresh: {self.last_refresh_var.get()}\n"
            f"Status: {self.status_var.get()}"
        )

    def copy_summary_snapshot(self) -> None:
        snapshot = self._summary_snapshot_text()
        self.root.clipboard_clear()
        self.root.clipboard_append(snapshot)
        self.status_var.set("Summary snapshot copied to clipboard.")
        self._update_menu_summary()

    def _apply_window_icon(self) -> None:
        search_dirs: list[Path] = []
        meipass = getattr(sys, "_MEIPASS", None)
        if meipass:
            search_dirs.append(Path(meipass))
        search_dirs.append(Path(__file__).resolve().parent)

        for base in search_dirs:
            icon_path = base / "assets" / "icons" / APP_ICON_FILE
            if not icon_path.exists():
                continue
            try:
                self._window_icon = tk.PhotoImage(file=str(icon_path))
                self.root.iconphoto(True, self._window_icon)
                return
            except tk.TclError:
                continue

    def trigger_refresh(self) -> None:
        if self.refresh_in_progress:
            return

        url = self.url_var.get().strip()
        if not url:
            self.status_var.set("Enter a monitor URL to start refreshing.")
            self._update_menu_summary()
            return

        self.refresh_in_progress = True
        self.status_var.set("Refreshing from monitor page...")
        self._update_menu_summary()

        worker = threading.Thread(
            target=self._refresh_worker,
            args=(url,),
            daemon=True,
        )
        worker.start()

    def _refresh_worker(self, url: str) -> None:
        try:
            html = fetch_html(url)
            records = parse_monitor_page(html)
            if not records:
                raise ValueError("No printer rows were parsed. The page layout may have changed.")

            low_alerts = build_low_alerts(records)
            current_empties = build_current_empties(records)
            scan_time = now_iso()

            with self.state_lock:
                changes = self.state_store.reconcile(current_empties, low_alerts, scan_time)
                open_empties = self.state_store.get_open_empties()
                events = self.state_store.get_events()

            payload = {
                "scan_time": scan_time,
                "records": records,
                "low_alerts": low_alerts,
                "open_empties": open_empties,
                "events": events,
                "changes": changes,
            }
            self.root.after(0, lambda: self._apply_refresh(payload))
        except urllib.error.URLError as exc:
            self.root.after(0, lambda: self._refresh_error(f"Network error: {exc}"))
        except Exception as exc:  # broad by design to keep GUI responsive
            self.root.after(0, lambda: self._refresh_error(str(exc)))

    def _apply_refresh(self, payload: dict[str, Any]) -> None:
        self.refresh_in_progress = False

        prior_empty_keys = set(self.open_empties.keys())
        prior_low_keys = {
            (alert.printer_id, alert.location, alert.item, alert.severity, alert.level, alert.source)
            for alert in self.low_alerts
        }

        self.records = payload["records"]
        self.low_alerts = payload["low_alerts"]
        self.open_empties = payload["open_empties"]
        self.events = payload["events"]
        self._update_summary_counts()

        self.last_refresh_var.set(display_time(payload["scan_time"]))

        self._refresh_low_tree()
        self._refresh_empty_tree()
        self._refresh_history_tree()
        self._populate_service_now_fields()

        changes = payload.get("changes", {})
        self.status_var.set(
            f"Refresh complete. New empties: {changes.get('new_empties', 0)} | "
            f"Marked filled: {changes.get('new_filled', 0)} | "
            f"New low alerts: {changes.get('new_low_alerts', 0)} | "
            f"Resolved low alerts: {changes.get('resolved_low_alerts', 0)}"
        )
        self._update_menu_summary()

        current_empty_keys = set(self.open_empties.keys())
        new_empty_keys = sorted(current_empty_keys - prior_empty_keys)
        new_empty_rows = [self.open_empties[key] for key in new_empty_keys if key in self.open_empties]

        current_low_keys = {
            (alert.printer_id, alert.location, alert.item, alert.severity, alert.level, alert.source): alert
            for alert in self.low_alerts
        }
        new_low_alerts = [current_low_keys[key] for key in current_low_keys.keys() - prior_low_keys]
        self._notify_refresh_changes(new_empty_rows, new_low_alerts)

        interval = max(1, self.refresh_interval_var.get())
        self.next_auto_refresh_epoch = datetime.now().timestamp() + (interval * 60)

    def _refresh_error(self, message: str) -> None:
        self.refresh_in_progress = False
        self.status_var.set(f"Refresh failed: {message}")
        self._update_menu_summary()
        if self.notifications_enabled_var.get():
            self.notification_manager.send(APP_NAME, f"Refresh failed: {message}")

        interval = max(1, self.refresh_interval_var.get())
        self.next_auto_refresh_epoch = datetime.now().timestamp() + (interval * 60)

    def _refresh_low_tree(self) -> None:
        for item in self.low_tree.get_children():
            self.low_tree.delete(item)
        self.low_alert_lookup = {}

        for idx, alert in enumerate(self._filtered_low_alerts()):
            if alert.severity == "Red":
                row_tag = "redrow"
            elif alert.severity == "Yellow":
                row_tag = "yellowrow"
            else:
                row_tag = "evenrow" if idx % 2 == 0 else "oddrow"
            row_id = f"low_{idx}"
            self.low_tree.insert(
                "",
                "end",
                iid=row_id,
                values=(
                    alert.printer_id,
                    alert.location,
                    alert.description,
                    alert.item,
                    alert.severity,
                    alert.level,
                    alert.source,
                ),
                tags=(row_tag,),
            )
            self.low_alert_lookup[row_id] = alert

    def _refresh_empty_tree(self) -> None:
        selected = self.empty_tree.selection()
        selected_key = selected[0] if selected else None

        for item in self.empty_tree.get_children():
            self.empty_tree.delete(item)

        rows = sorted(self._filtered_open_empties(), key=lambda row: (row.get("printer_id", ""), row.get("tray", "")))

        for idx, row in enumerate(rows):
            row_tag = "evenrow" if idx % 2 == 0 else "oddrow"
            key = row.get("key", f"{row.get('printer_id', '')}::{row.get('tray', '')}")
            self.empty_tree.insert(
                "",
                "end",
                iid=key,
                values=(
                    row.get("printer_id", ""),
                    row.get("location", ""),
                    row.get("tray", ""),
                    row.get("tray", ""),
                    display_time(row.get("since", "")),
                    display_time(row.get("last_seen", "")),
                ),
                tags=(row_tag,),
            )

        if selected_key and self.empty_tree.exists(selected_key):
            self.empty_tree.selection_set(selected_key)

    def _refresh_history_tree(self) -> None:
        for item in self.history_tree.get_children():
            self.history_tree.delete(item)

        recent = sorted(
            self._filtered_events(),
            key=lambda event: parse_iso(event.get("timestamp", "")) or datetime.min,
            reverse=True,
        )[:1000]

        for idx, event in enumerate(recent):
            row_tag = "evenrow" if idx % 2 == 0 else "oddrow"
            self.history_tree.insert(
                "",
                "end",
                values=(
                    display_time(event.get("timestamp", "")),
                    event.get("event_type", ""),
                    event.get("printer_id", ""),
                    event.get("location", ""),
                    event.get("description", ""),
                    event.get("item", event.get("tray", "")),
                    event.get("severity", ""),
                    event.get("level", ""),
                    event.get("note", ""),
                ),
                tags=(row_tag,),
            )

    def _notify_refresh_changes(self, new_empty_rows: list[dict[str, str]], new_low_alerts: list[LowAlert]) -> None:
        if not self.notifications_enabled_var.get():
            return

        if new_empty_rows:
            first = new_empty_rows[0]
            message = (
                f"{len(new_empty_rows)} new empty tray alert(s). "
                f"First: printer {first.get('printer_id', '')} {first.get('tray', '')} ({first.get('location', '')})."
            )
            self.notification_manager.send(APP_NAME, message)

        if new_low_alerts:
            first = new_low_alerts[0]
            message = (
                f"{len(new_low_alerts)} new low supply alert(s). "
                f"First: {first.severity} - printer {first.printer_id} {first.item} {first.level} ({first.location})."
            )
            self.notification_manager.send(APP_NAME, message)

    def _set_text_widget(self, widget: tk.Text, value: str) -> None:
        widget.delete("1.0", tk.END)
        widget.insert("1.0", value)

    def _selected_low_alert(self) -> LowAlert | None:
        selected = self.low_tree.selection()
        if not selected:
            return None
        return self.low_alert_lookup.get(selected[0])

    def _on_low_tree_select(self, _event: tk.Event | None = None) -> None:
        if self.low_tree.selection():
            self.active_alert_source = "low"
            empty_selected = self.empty_tree.selection()
            if empty_selected:
                self.empty_tree.selection_remove(*empty_selected)
        self._populate_service_now_fields()

    def _on_empty_tree_select(self, _event: tk.Event | None = None) -> None:
        if self.empty_tree.selection():
            self.active_alert_source = "empty"
            low_selected = self.low_tree.selection()
            if low_selected:
                self.low_tree.selection_remove(*low_selected)
        self._populate_service_now_fields()

    def _selected_alert_context(self) -> tuple[str, dict[str, str] | LowAlert] | None:
        ordered_sources = [self.active_alert_source, "low", "empty"]
        for source in ordered_sources:
            if source == "low":
                alert = self._selected_low_alert()
                if alert is not None:
                    return ("low", alert)
            if source == "empty":
                tray = self._selected_tray()
                if tray is not None:
                    return ("empty", tray)
        return None

    def _selected_alert_key(self, context: tuple[str, dict[str, str] | LowAlert]) -> str:
        source, payload = context
        if source == "low":
            alert = payload  # type: ignore[assignment]
            if isinstance(alert, LowAlert):
                return f"low::{alert.printer_id}::{alert.item}::{alert.severity}::{alert.level}"
            return "low::unknown"
        tray = payload  # type: ignore[assignment]
        if isinstance(tray, dict):
            return tray.get("key", "")
        return ""

    def _record_for_printer(self, printer_id: str) -> PrinterRecord | None:
        for record in self.records:
            if record.printer_id == printer_id:
                return record
        return None

    def _open_report_window(self, title: str, report_text: str) -> None:
        window = tk.Toplevel(self.root)
        window.title(title)
        window.geometry("860x620")
        window.minsize(640, 420)
        window.configure(bg=self.colors["window_bg"])

        container = ttk.Frame(window, style="App.TFrame", padding=(14, 12, 14, 12))
        container.pack(fill="both", expand=True)
        container.columnconfigure(0, weight=1)
        container.rowconfigure(0, weight=1)

        report_widget = tk.Text(
            container,
            wrap="word",
            font=(self.font_family, 11),
            bg=self.colors["surface_raised"],
            fg=self.colors["text"],
            insertbackground=self.colors["title"],
            relief="flat",
            bd=0,
            highlightthickness=1,
            highlightbackground=self.colors["border"],
            highlightcolor=self.colors["accent"],
            padx=12,
            pady=10,
        )
        report_widget.grid(row=0, column=0, sticky="nsew")
        report_widget.insert("1.0", report_text)
        report_widget.configure(state="disabled")

        footer = ttk.Frame(container, style="App.TFrame")
        footer.grid(row=1, column=0, sticky="ew", pady=(10, 0))
        ttk.Button(
            footer,
            text="Copy Report",
            style="GhostDark.TButton",
            command=lambda: self._copy_report_text(report_text),
        ).pack(side="left")
        ttk.Button(footer, text="Close", style="GhostDark.TButton", command=window.destroy).pack(side="left", padx=(8, 0))

    def _copy_report_text(self, report_text: str) -> None:
        self.root.clipboard_clear()
        self.root.clipboard_append(report_text)
        self.status_var.set("Report copied to clipboard.")
        self._update_menu_summary()

    def _build_low_alert_report(self, alert: LowAlert) -> str:
        now_label = display_time(now_iso())
        record = self._record_for_printer(alert.printer_id)

        lines = [
            f"[{now_label}] Low Supply Alert Report",
            f"Printer: {alert.printer_id}",
            f"Served By: {alert.location}",
            f"Description: {alert.description}",
            f"Alert Item: {alert.item}",
            f"Severity: {alert.severity}",
            f"Level/State: {alert.level}",
            f"Source: {alert.source}",
        ]

        if record is not None:
            lines.append(f"Status Message: {record.status_message or 'None'}")
            lines.append(f"Printer Text: {record.printer_text or 'None'}")
            snapshot_items = [
                ("toner_k", "Black Toner/Ink"),
                ("toner_c", "Cyan Toner/Ink"),
                ("toner_m", "Magenta Toner/Ink"),
                ("toner_y", "Yellow Toner/Ink"),
                ("drum_k", "Black Drum"),
                ("drum_c", "Cyan Drum"),
                ("drum_m", "Magenta Drum"),
                ("drum_y", "Yellow Drum"),
                ("belt", "Transfer Belt"),
                ("fuser", "Fuser"),
            ]
            levels = [f"- {label}: {record.levels[key]}%" for key, label in snapshot_items if key in record.levels]
            if levels:
                lines.append("Latest Component Levels:")
                lines.extend(levels)

        steps: list[str]
        item_lower = alert.item.lower()
        if "printer down" in item_lower:
            steps = [
                "- Verify device power and front-panel error state.",
                "- Check network link and ping the printer IP.",
                "- Reseat network cable or restart network interface as needed.",
                "- Reboot printer if link is up but queue is unresponsive.",
                "- Run a test print and confirm the monitor clears the down state.",
            ]
        elif "toner/ink" in item_lower:
            steps = [
                "- Verify the reported color cartridge level on the printer panel.",
                "- Replace or reseat the matching toner/ink cartridge.",
                "- Shake/reseat cartridge if reading is stale, then re-check.",
                "- Print a status/config page to confirm level update.",
                "- Update the ticket with part used and result.",
            ]
        elif "drum" in item_lower:
            steps = [
                "- Verify drum life from the device maintenance screen.",
                "- Replace or reseat the drum unit for the affected color.",
                "- Clear maintenance prompts if required by model workflow.",
                "- Print a quality page to confirm issue is resolved.",
                "- Document maintenance action in the ticket.",
            ]
        elif "fuser" in item_lower:
            steps = [
                "- Confirm fuser life/replace message on printer panel.",
                "- Replace fuser assembly using model procedure.",
                "- Reset maintenance counter if required.",
                "- Run warm-up and test print verification.",
                "- Update ticket with replacement confirmation.",
            ]
        elif "transfer belt" in item_lower:
            steps = [
                "- Confirm transfer belt status from diagnostics/consumables.",
                "- Replace belt assembly if depleted/faulted.",
                "- Inspect paper path for debris before restart.",
                "- Run calibration and print test output.",
                "- Log part replacement and printer status in ticket.",
            ]
        else:
            steps = [
                "- Verify alert condition on device panel.",
                "- Perform required refill/replacement action.",
                "- Run a test print and confirm monitor status clears.",
                "- Update ServiceNow ticket with findings and completion notes.",
            ]

        lines.append("Recommended Resolution Steps:")
        lines.extend(steps)
        return "\n".join(lines)

    def _build_empty_tray_report(self, tray: dict[str, str]) -> str:
        now_label = display_time(now_iso())
        lines = [
            f"[{now_label}] Empty Tray Alert Report",
            f"Printer: {tray.get('printer_id', '')}",
            f"Served By: {tray.get('location', '')}",
            f"Description: {tray.get('description', '')}",
            f"Tray: {tray.get('tray', '')}",
            f"Empty Since: {display_time(tray.get('since', ''))}",
            f"Last Seen Empty: {display_time(tray.get('last_seen', ''))}",
            f"Status Message: {tray.get('status_message', '') or 'None'}",
            f"Printer Text: {tray.get('printer_text', '') or 'None'}",
            "Recommended Resolution Steps:",
            "- Go onsite and verify the tray is physically empty.",
            "- Refill the tray with the correct paper size/type.",
            "- Confirm tray guides and paper settings are correct.",
            "- Clear panel warnings and run a test print.",
            "- Mark tray filled in the app and update ServiceNow ticket.",
        ]
        return "\n".join(lines)

    def _open_selected_low_alert_report(self, event: tk.Event | None = None) -> None:
        if event is not None:
            row_id = self.low_tree.identify_row(event.y)
            if row_id:
                self.low_tree.selection_set(row_id)
                self.active_alert_source = "low"

        alert = self._selected_low_alert()
        if alert is None:
            return
        report = self._build_low_alert_report(alert)
        self._open_report_window(f"Low Alert Report - {alert.printer_id}", report)

    def _open_selected_empty_alert_report(self, event: tk.Event | None = None) -> None:
        if event is not None:
            row_id = self.empty_tree.identify_row(event.y)
            if row_id:
                self.empty_tree.selection_set(row_id)
                self.active_alert_source = "empty"

        tray = self._selected_tray()
        if tray is None:
            return
        report = self._build_empty_tray_report(tray)
        self._open_report_window(f"Empty Tray Report - {tray.get('printer_id', '')}", report)

    def _populate_service_now_fields(self) -> None:
        context = self._selected_alert_context()
        if context is None:
            self._set_text_widget(self.worknote_text, "")
            self._set_text_widget(self.description_text, "")
            self._set_text_widget(self.joke_text, "")
            self.joke_tray_key = ""
            return
        self.generate_worknote()
        self.generate_description()
        context_key = self._selected_alert_key(context)
        if context_key != self.joke_tray_key or not self.joke_text.get("1.0", "end-1c").strip():
            self.generate_joke()
            self.joke_tray_key = context_key

    def _auto_refresh_tick(self) -> None:
        if self.auto_refresh_var.get() and not self.refresh_in_progress:
            now_epoch = datetime.now().timestamp()
            if self.next_auto_refresh_epoch == 0.0 or now_epoch >= self.next_auto_refresh_epoch:
                self.trigger_refresh()

        self.root.after(1000, self._auto_refresh_tick)

    def _selected_tray(self) -> dict[str, str] | None:
        selected = self.empty_tree.selection()
        if not selected:
            return None
        key = selected[0]
        return self.open_empties.get(key)

    def generate_worknote(self) -> None:
        context = self._selected_alert_context()
        if context is None:
            self._set_text_widget(self.worknote_text, "")
            return

        source, payload = context
        if source == "low" and isinstance(payload, LowAlert):
            generated = self._build_low_worknote_text(payload)
        elif source == "empty" and isinstance(payload, dict):
            generated = self._build_worknote_text(payload)
        else:
            self._set_text_widget(self.worknote_text, "")
            return
        self._set_text_widget(self.worknote_text, generated)

    def generate_description(self) -> None:
        context = self._selected_alert_context()
        if context is None:
            self._set_text_widget(self.description_text, "")
            return
        source, payload = context
        if source == "low" and isinstance(payload, LowAlert):
            generated = self._build_low_description_text(payload)
        elif source == "empty" and isinstance(payload, dict):
            generated = self._build_description_text(payload)
        else:
            self._set_text_widget(self.description_text, "")
            return
        self._set_text_widget(self.description_text, generated)

    def generate_joke(self) -> None:
        context = self._selected_alert_context()
        if context is None:
            self._set_text_widget(self.joke_text, "")
            self.joke_tray_key = ""
            return
        source, payload = context
        if source == "low" and isinstance(payload, LowAlert):
            generated = self._build_low_joke_text(payload)
        elif source == "empty" and isinstance(payload, dict):
            generated = self._build_joke_text(payload)
        else:
            self._set_text_widget(self.joke_text, "")
            self.joke_tray_key = ""
            return
        self._set_text_widget(self.joke_text, generated)
        self.joke_tray_key = self._selected_alert_key(context)

    def _build_worknote_text(self, tray: dict[str, str]) -> str:
        now_label = display_time(now_iso())
        since = display_time(tray.get("since", ""))
        last_seen = display_time(tray.get("last_seen", ""))
        printer_id = tray.get("printer_id", "")
        description = tray.get("description", "")
        location = tray.get("location", "Pattee")
        tray_name = tray.get("tray", "")
        status = tray.get("status_message", "") or "None"
        printer_text = tray.get("printer_text", "") or "None"
        mode = self.worknote_mode_var.get()

        if mode == "Refilled and Tested":
            return (
                f"[{now_label}] Refill completed for printer {printer_id} ({description}) in {location}.\n"
                f"Issue addressed: {tray_name} empty.\n"
                f"First detected empty: {since}.\n"
                f"Most recent empty detection: {last_seen}.\n"
                "Actions performed:\n"
                f"- Arrived on site and verified {tray_name} was empty.\n"
                f"- Refilled {tray_name} with paper.\n"
                "- Ran a test print and confirmed successful output.\n"
                "- No additional supply/tray faults observed after refill.\n"
                "Printer returned to service."
            )

        return (
            f"[{now_label}] Monitoring alert for printer {printer_id} ({description}) in {location}.\n"
            f"Current issue: {tray_name} empty.\n"
            f"First detected empty: {since}.\n"
            f"Most recent detection: {last_seen}.\n"
            f"Status Message: {status}\n"
            f"Printer Text: {printer_text}\n"
            "Planned action:\n"
            f"- Refill {tray_name}.\n"
            "- Run test print.\n"
            "- Update ticket with verification results."
        )

    def _build_description_text(self, tray: dict[str, str]) -> str:
        since = display_time(tray.get("since", ""))
        last_seen = display_time(tray.get("last_seen", ""))
        printer_id = tray.get("printer_id", "")
        description = tray.get("description", "")
        location = tray.get("location", "Pattee")
        tray_name = tray.get("tray", "")
        mode = self.worknote_mode_var.get()

        if mode == "Refilled and Tested":
            return (
                f"Printer {printer_id} ({description}) in {location} had {tray_name} empty. "
                f"First detected {since}, most recently seen {last_seen}. "
                "Tray was refilled, test print completed, and device returned to normal service."
            )

        return (
            f"Printer {printer_id} ({description}) in {location} is reporting {tray_name} empty. "
            f"First detected {since}, most recently seen {last_seen}. "
            "Technician needs to refill the tray and run a test print."
        )

    def _build_joke_text(self, tray: dict[str, str]) -> str:
        now_label = display_time(now_iso())
        use_cs_joke = random.random() < 0.35
        templates = CS_MAJOR_JOKES if use_cs_joke else PRINTER_JOKES
        template = random.choice(templates)
        body = template.format(
            printer_id=tray.get("printer_id", "Unknown"),
            tray=tray.get("tray", "the tray"),
            location=tray.get("location", "Pattee"),
        )
        return f"[{now_label}] {body}"

    def _build_low_worknote_text(self, alert: LowAlert) -> str:
        now_label = display_time(now_iso())
        mode = self.worknote_mode_var.get()
        record = self._record_for_printer(alert.printer_id)
        status_message = record.status_message if record else "None"
        printer_text = record.printer_text if record else "None"

        if mode == "Refilled and Tested":
            return (
                f"[{now_label}] Supply/maintenance action completed for printer {alert.printer_id} "
                f"({alert.description}) in {alert.location}.\n"
                f"Issue addressed: {alert.item} alert ({alert.severity}, {alert.level}).\n"
                "Actions performed:\n"
                f"- Verified alert condition for {alert.item}.\n"
                f"- Resolved maintenance/supply issue related to {alert.item}.\n"
                "- Ran test print and validated normal output.\n"
                "- Confirmed monitor alert state is stable after service.\n"
                "Printer returned to service."
            )

        return (
            f"[{now_label}] Monitoring alert for printer {alert.printer_id} ({alert.description}) in {alert.location}.\n"
            f"Current issue: {alert.item} alert.\n"
            f"Severity: {alert.severity}\n"
            f"Level/State: {alert.level}\n"
            f"Alert Source: {alert.source}\n"
            f"Status Message: {status_message or 'None'}\n"
            f"Printer Text: {printer_text or 'None'}\n"
            "Planned action:\n"
            f"- Inspect and resolve {alert.item} condition.\n"
            "- Run test print.\n"
            "- Update ticket with verification results."
        )

    def _build_low_description_text(self, alert: LowAlert) -> str:
        mode = self.worknote_mode_var.get()
        if mode == "Refilled and Tested":
            return (
                f"Printer {alert.printer_id} ({alert.description}) in {alert.location} had a "
                f"{alert.severity} {alert.item} alert ({alert.level}). "
                "Issue was serviced and printer functionality was validated with a test print."
            )
        return (
            f"Printer {alert.printer_id} ({alert.description}) in {alert.location} is reporting a "
            f"{alert.severity} {alert.item} alert ({alert.level}). "
            "Technician should inspect the supply/maintenance condition and verify with a test print."
        )

    def _build_low_joke_text(self, alert: LowAlert) -> str:
        now_label = display_time(now_iso())
        use_cs_joke = random.random() < 0.35
        templates = CS_MAJOR_JOKES if use_cs_joke else PRINTER_JOKES
        template = random.choice(templates)
        body = template.format(
            printer_id=alert.printer_id,
            tray=alert.item,
            location=alert.location,
        )
        return f"[{now_label}] {body}"

    def copy_worknote(self) -> None:
        text = self.worknote_text.get("1.0", "end-1c").strip()
        if not text:
            self.generate_worknote()
            text = self.worknote_text.get("1.0", "end-1c").strip()

        if not text:
            messagebox.showinfo("No Worknote", "Select a low supply or empty tray alert first.")
            return

        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        self.status_var.set("Worknote copied to clipboard.")
        self._update_menu_summary()

    def copy_description(self) -> None:
        text = self.description_text.get("1.0", "end-1c").strip()
        if not text:
            self.generate_description()
            text = self.description_text.get("1.0", "end-1c").strip()
        if not text:
            messagebox.showinfo("No Description", "Select a low supply or empty tray alert first.")
            return

        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        self.status_var.set("ServiceNow description copied to clipboard.")
        self._update_menu_summary()

    def copy_joke(self) -> None:
        text = self.joke_text.get("1.0", "end-1c").strip()
        if not text:
            self.generate_joke()
            text = self.joke_text.get("1.0", "end-1c").strip()
        if not text:
            messagebox.showinfo("No Joke", "Select a low supply or empty tray alert first.")
            return

        self.root.clipboard_clear()
        self.root.clipboard_append(text)
        self.status_var.set("Printer keys joke copied to clipboard.")
        self._update_menu_summary()

    def mark_selected_filled(self) -> None:
        tray = self._selected_tray()
        if tray is None:
            messagebox.showinfo("No Selection", "Select an empty tray to mark filled.")
            return

        description = f"{tray.get('printer_id', '')} - {tray.get('description', '')} ({tray.get('tray', '')})"
        if not messagebox.askyesno("Mark Filled", f"Mark this tray as filled?\n\n{description}"):
            return

        key = tray.get("key", "")
        timestamp = now_iso()
        with self.state_lock:
            updated = self.state_store.manual_mark_filled(key, timestamp)
            if updated:
                self.open_empties = self.state_store.get_open_empties()
                self.events = self.state_store.get_events()

        if not updated:
            self.status_var.set("Tray was already resolved.")
            return

        self._update_summary_counts()
        self._refresh_empty_tree()
        self._refresh_history_tree()
        self._populate_service_now_fields()
        self.status_var.set("Tray marked filled manually.")
        self._update_menu_summary()

    def export_history_csv(self) -> None:
        export_rows = self._filtered_events()
        if not export_rows:
            messagebox.showinfo("No Data", "No history events to export yet.")
            return

        default_name = f"alert_history_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        output_path = filedialog.asksaveasfilename(
            title="Export Alert History",
            defaultextension=".csv",
            initialfile=default_name,
            filetypes=[("CSV Files", "*.csv")],
        )
        if not output_path:
            return

        fields = [
            "timestamp",
            "event_type",
            "printer_id",
            "location",
            "description",
            "item",
            "tray",
            "severity",
            "level",
            "source",
            "empty_since",
            "last_seen",
            "status_message",
            "printer_text",
            "note",
        ]

        try:
            with open(output_path, "w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=fields)
                writer.writeheader()
                for event in export_rows:
                    writer.writerow({field: event.get(field, "") for field in fields})
            self.status_var.set(f"Exported history CSV: {output_path}")
            self._update_menu_summary()
        except OSError as exc:
            messagebox.showerror("Export Failed", str(exc))


def main() -> None:
    root = tk.Tk()
    PrinterMonitorApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
