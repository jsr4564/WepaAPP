# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['/Users/jackshetterly/Documents/New project/printer_monitor_app/main.py'],
    pathex=[],
    binaries=[],
    datas=[],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='PrinterSupplyTrayMonitor',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['/Users/jackshetterly/Documents/New project/printer_monitor_app/assets/icons/PrinterSupplyTrayMonitor.icns'],
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='PrinterSupplyTrayMonitor',
)
app = BUNDLE(
    coll,
    name='PrinterSupplyTrayMonitor.app',
    icon='/Users/jackshetterly/Documents/New project/printer_monitor_app/assets/icons/PrinterSupplyTrayMonitor.icns',
    bundle_identifier='org.anonymous.printersupplytraymonitor',
)
