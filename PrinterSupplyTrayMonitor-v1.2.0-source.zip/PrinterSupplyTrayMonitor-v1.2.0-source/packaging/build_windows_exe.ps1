param(
    [string]$Version = "1.0.0"
)

$ErrorActionPreference = "Stop"

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectDir = Split-Path -Parent $ScriptDir
$DistDir = Join-Path $ProjectDir "dist"
$ReleaseDir = Join-Path $ProjectDir "release\windows"
$AppExeName = "PrinterSupplyTrayMonitor"
$IconIco = Join-Path $ProjectDir "assets\icons\PrinterSupplyTrayMonitor.ico"

py (Join-Path $ScriptDir "generate_icons.py")
py -m pip install --upgrade pyinstaller
py -m PyInstaller --noconfirm --clean --windowed --onefile --name $AppExeName --icon $IconIco (Join-Path $ProjectDir "main.py")

New-Item -ItemType Directory -Force -Path $ReleaseDir | Out-Null
$PortableExe = Join-Path $ReleaseDir "$AppExeName-$Version.exe"
Copy-Item -Force (Join-Path $DistDir "$AppExeName.exe") $PortableExe
Write-Host "Created $PortableExe"

$ProgramFilesX86 = ${env:ProgramFiles(x86)}
if (-not $ProgramFilesX86) {
    $ProgramFilesX86 = $env:ProgramFiles
}

$InnoCompiler = Join-Path $ProgramFilesX86 "Inno Setup 6\ISCC.exe"
if (Test-Path $InnoCompiler) {
    & $InnoCompiler (Join-Path $ScriptDir "windows_installer.iss") "/DAppVersion=$Version" "/DRootDir=$ProjectDir" "/DAppExeName=$AppExeName.exe" "/DIconFile=$IconIco"
    Write-Host "Created installer in $ReleaseDir"
} else {
    Write-Host "Inno Setup not found. Skipping installer build."
    Write-Host "Install Inno Setup 6 and rerun to generate a setup .exe."
}
