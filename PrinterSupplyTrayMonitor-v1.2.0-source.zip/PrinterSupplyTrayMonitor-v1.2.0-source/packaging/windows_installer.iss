#ifndef AppVersion
#define AppVersion "1.0.0"
#endif

#ifndef RootDir
#define RootDir ".."
#endif

#ifndef AppExeName
#define AppExeName "PrinterSupplyTrayMonitor.exe"
#endif

#ifndef IconFile
#define IconFile "..\assets\icons\PrinterSupplyTrayMonitor.ico"
#endif

#define MyAppName "Printer Supply & Tray Monitor"
#define MyAppPublisher "Anonymous"
#define MyAppExeName AppExeName

[Setup]
AppId={{D2F1B264-8145-4EA5-9949-4F7EE9E5AB6C}
AppName={#MyAppName}
AppVersion={#AppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\Printer Supply Tray Monitor
DefaultGroupName=Printer Supply Tray Monitor
DisableProgramGroupPage=yes
OutputDir={#RootDir}\release\windows
OutputBaseFilename=PrinterSupplyTrayMonitor-{#AppVersion}-setup
SetupIconFile={#IconFile}
Compression=lzma
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional icons:"; Flags: unchecked

[Files]
Source: "{#RootDir}\dist\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch {#MyAppName}"; Flags: nowait postinstall skipifsilent
