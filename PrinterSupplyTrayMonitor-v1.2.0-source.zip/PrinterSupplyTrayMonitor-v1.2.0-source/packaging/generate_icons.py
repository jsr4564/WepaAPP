#!/usr/bin/env python3
"""Generate sleek minimal app icon assets for Printer Supply & Tray Monitor.

Outputs in assets/icons:
- PrinterSupplyTrayMonitor-1024.png
- PrinterSupplyTrayMonitor-256.png
- PrinterSupplyTrayMonitor.ico
- PrinterSupplyTrayMonitor.icns (on macOS when iconutil is available)
- PrinterSupplyTrayMonitor.iconset/*
"""

from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter

ROOT = Path(__file__).resolve().parents[1]
ASSETS_DIR = ROOT / "assets" / "icons"
MASTER_PNG = ASSETS_DIR / "PrinterSupplyTrayMonitor-1024.png"
PREVIEW_PNG = ASSETS_DIR / "PrinterSupplyTrayMonitor-256.png"
ICO_PATH = ASSETS_DIR / "PrinterSupplyTrayMonitor.ico"
ICNS_PATH = ASSETS_DIR / "PrinterSupplyTrayMonitor.icns"
ICONSET_DIR = ASSETS_DIR / "PrinterSupplyTrayMonitor.iconset"

ICONSET_SPECS = [
    ("icon_16x16.png", 16),
    ("icon_16x16@2x.png", 32),
    ("icon_32x32.png", 32),
    ("icon_32x32@2x.png", 64),
    ("icon_128x128.png", 128),
    ("icon_128x128@2x.png", 256),
    ("icon_256x256.png", 256),
    ("icon_256x256@2x.png", 512),
    ("icon_512x512.png", 512),
    ("icon_512x512@2x.png", 1024),
]


def _lerp(a: int, b: int, t: float) -> int:
    return int(round(a + (b - a) * t))


def build_master_icon(size: int = 1024) -> Image.Image:
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))

    # Outer shadow base.
    margin = int(size * 0.08)
    card_size = size - (margin * 2)
    radius = int(size * 0.2)

    shadow = Image.new("RGBA", (card_size, card_size), (0, 0, 0, 0))
    ImageDraw.Draw(shadow).rounded_rectangle(
        (0, 0, card_size - 1, card_size - 1),
        radius=radius,
        fill=(0, 0, 0, 180),
    )
    shadow = shadow.filter(ImageFilter.GaussianBlur(radius=int(size * 0.03)))
    canvas.alpha_composite(shadow, (margin + int(size * 0.01), margin + int(size * 0.02)))

    # Card background gradient.
    card = Image.new("RGBA", (card_size, card_size), (0, 0, 0, 0))
    card_px = card.load()
    for y in range(card_size):
        t = y / max(1, card_size - 1)
        r = _lerp(24, 41, t)
        g = _lerp(31, 48, t)
        b = _lerp(28, 38, t)
        for x in range(card_size):
            card_px[x, y] = (r, g, b, 255)

    glow = Image.new("RGBA", (card_size, card_size), (0, 0, 0, 0))
    glow_draw = ImageDraw.Draw(glow)
    glow_draw.ellipse(
        (int(card_size * 0.04), int(card_size * 0.02), int(card_size * 0.92), int(card_size * 0.60)),
        fill=(124, 176, 137, 56),
    )
    glow_draw.ellipse(
        (int(card_size * 0.16), int(card_size * 0.54), int(card_size * 0.86), int(card_size * 1.05)),
        fill=(0, 0, 0, 60),
    )
    card.alpha_composite(glow)

    mask = Image.new("L", (card_size, card_size), 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, card_size - 1, card_size - 1), radius=radius, fill=255)
    canvas.paste(card, (margin, margin), mask)

    draw = ImageDraw.Draw(canvas)

    draw.rounded_rectangle(
        (margin, margin, margin + card_size - 1, margin + card_size - 1),
        radius=radius,
        outline=(103, 126, 107, 190),
        width=max(4, int(size * 0.006)),
    )

    # Printer glyph geometry.
    cx = size // 2
    cy = int(size * 0.54)
    printer_w = int(size * 0.48)
    printer_h = int(size * 0.30)
    body_l = cx - printer_w // 2
    body_t = cy - printer_h // 2
    body_r = cx + printer_w // 2
    body_b = cy + printer_h // 2

    top_w = int(printer_w * 0.58)
    top_h = int(size * 0.11)
    top_l = cx - top_w // 2
    top_t = body_t - int(size * 0.085)
    top_r = cx + top_w // 2
    top_b = top_t + top_h

    printer_shadow = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    sdraw = ImageDraw.Draw(printer_shadow)
    sdraw.rounded_rectangle(
        (body_l + int(size * 0.008), body_t + int(size * 0.014), body_r + int(size * 0.008), body_b + int(size * 0.014)),
        radius=int(size * 0.05),
        fill=(0, 0, 0, 86),
    )
    printer_shadow = printer_shadow.filter(ImageFilter.GaussianBlur(radius=int(size * 0.009)))
    canvas.alpha_composite(printer_shadow)

    # Top module.
    draw.rounded_rectangle(
        (top_l, top_t, top_r, top_b),
        radius=int(size * 0.03),
        fill=(235, 241, 233, 240),
    )

    # Main body.
    draw.rounded_rectangle(
        (body_l, body_t, body_r, body_b),
        radius=int(size * 0.05),
        fill=(232, 238, 230, 246),
    )

    # Paper.
    paper_w = int(printer_w * 0.45)
    paper_h = int(size * 0.16)
    paper_l = cx - paper_w // 2
    paper_t = top_t - int(size * 0.06)
    paper_r = cx + paper_w // 2
    paper_b = paper_t + paper_h
    draw.rounded_rectangle(
        (paper_l, paper_t, paper_r, paper_b),
        radius=int(size * 0.02),
        fill=(250, 252, 249, 250),
    )

    # Paper lines.
    line_color = (97, 119, 106, 190)
    line_w = max(3, int(size * 0.004))
    y1 = paper_t + int(paper_h * 0.42)
    y2 = paper_t + int(paper_h * 0.66)
    draw.line((paper_l + int(size * 0.03), y1, paper_r - int(size * 0.03), y1), fill=line_color, width=line_w)
    draw.line((paper_l + int(size * 0.03), y2, paper_r - int(size * 0.12), y2), fill=line_color, width=line_w)

    # Slot + tray.
    slot_y = body_t + int(printer_h * 0.36)
    draw.rounded_rectangle(
        (body_l + int(printer_w * 0.16), slot_y, body_r - int(printer_w * 0.16), slot_y + int(size * 0.022)),
        radius=int(size * 0.012),
        fill=(126, 147, 130, 210),
    )

    tray_t = body_b - int(size * 0.08)
    draw.rounded_rectangle(
        (body_l + int(printer_w * 0.22), tray_t, body_r - int(printer_w * 0.22), body_b - int(size * 0.02)),
        radius=int(size * 0.02),
        fill=(188, 202, 188, 245),
    )

    # Small supply status accent dot (minimal hint of monitoring state).
    dot_r = int(size * 0.03)
    dot_x = body_r - int(printer_w * 0.12)
    dot_y = body_t + int(printer_h * 0.16)
    draw.ellipse(
        (dot_x - dot_r, dot_y - dot_r, dot_x + dot_r, dot_y + dot_r),
        fill=(10, 132, 255, 230),
    )

    return canvas


def save_resized(master: Image.Image, out_path: Path, px: int) -> None:
    resized = master.resize((px, px), Image.Resampling.LANCZOS)
    resized.save(out_path)


def generate_iconset(master: Image.Image) -> None:
    ICONSET_DIR.mkdir(parents=True, exist_ok=True)
    for child in ICONSET_DIR.iterdir():
        if child.is_file():
            child.unlink()

    for filename, px in ICONSET_SPECS:
        save_resized(master, ICONSET_DIR / filename, px)


def generate_icns(master: Image.Image) -> None:
    iconutil = shutil.which("iconutil")
    if iconutil:
        try:
            subprocess.run(
                [iconutil, "-c", "icns", str(ICONSET_DIR), "-o", str(ICNS_PATH)],
                check=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            return
        except subprocess.CalledProcessError:
            pass

    # Fallback path works cross-platform when Pillow has ICNS support.
    master.save(ICNS_PATH, format="ICNS")


def generate_ico(master: Image.Image) -> None:
    master.save(
        ICO_PATH,
        format="ICO",
        sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)],
    )


def main() -> int:
    ASSETS_DIR.mkdir(parents=True, exist_ok=True)

    master = build_master_icon(1024)
    master.save(MASTER_PNG)
    save_resized(master, PREVIEW_PNG, 256)

    generate_iconset(master)
    generate_ico(master)
    generate_icns(master)

    print(f"Generated icon assets in: {ASSETS_DIR}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
