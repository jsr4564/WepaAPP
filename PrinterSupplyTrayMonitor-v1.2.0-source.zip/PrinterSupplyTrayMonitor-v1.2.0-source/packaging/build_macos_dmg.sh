#!/usr/bin/env bash
set -euo pipefail

APP_NAME="Printer Supply & Tray Monitor"
BUNDLE_NAME="PrinterSupplyTrayMonitor"
BUNDLE_ID="org.anonymous.printersupplytraymonitor"
VERSION="${1:-1.0.0}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(cd "${SCRIPT_DIR}/.." && pwd)"
ICON_ICNS="${PROJECT_DIR}/assets/icons/PrinterSupplyTrayMonitor.icns"
DIST_DIR="${PROJECT_DIR}/dist"
BUILD_DIR="${PROJECT_DIR}/build"
RELEASE_DIR="${PROJECT_DIR}/release/macos"
PKG_ROOT_DIR="${BUILD_DIR}/pkg_root"
DMG_STAGING_DIR="${BUILD_DIR}/dmg_staging"
APP_BUNDLE_PATH="${DIST_DIR}/${BUNDLE_NAME}.app"
PKG_PATH="${RELEASE_DIR}/${BUNDLE_NAME}-${VERSION}.pkg"
DMG_PATH="${RELEASE_DIR}/${BUNDLE_NAME}-${VERSION}.dmg"

python3 "${SCRIPT_DIR}/generate_icons.py"

python3 -m pip install --upgrade pyinstaller
python3 -m PyInstaller \
  --noconfirm \
  --clean \
  --windowed \
  --name "${BUNDLE_NAME}" \
  --osx-bundle-identifier "${BUNDLE_ID}" \
  --icon "${ICON_ICNS}" \
  "${PROJECT_DIR}/main.py"

rm -rf "${PKG_ROOT_DIR}" "${DMG_STAGING_DIR}"
mkdir -p "${PKG_ROOT_DIR}" "${DMG_STAGING_DIR}" "${RELEASE_DIR}"

cp -R "${APP_BUNDLE_PATH}" "${PKG_ROOT_DIR}/"

# Build a macOS installer package that installs the app to /Applications.
pkgbuild \
  --root "${PKG_ROOT_DIR}" \
  --identifier "${BUNDLE_ID}" \
  --version "${VERSION}" \
  --install-location "/Applications" \
  "${PKG_PATH}"

# Wrap the installer package in a DMG for distribution.
cp "${PKG_PATH}" "${DMG_STAGING_DIR}/"
hdiutil create \
  -volname "${APP_NAME}" \
  -srcfolder "${DMG_STAGING_DIR}" \
  -ov \
  -format UDZO \
  "${DMG_PATH}"

echo "Created installer package: ${PKG_PATH}"
echo "Created disk image: ${DMG_PATH}"
