# Changelog

All notable changes to this project are documented in this file.

## v1.2.0 - 2026-02-23

### Added
- Low-supply lifecycle history tracking in the `Alert History` tab (`low_open`, `low_update`, `low_resolved`).
- Low-supply history export in CSV alongside tray history events.
- Double-click generated report windows for both low-supply and empty-tray alerts.
- Shared text actions (worknote/description/joke generate+copy) that now work from either Low Supplies or Empty Trays selection.
- Printer-to-service-desk mapping by printer ID for:
  - Pattee Library Service Desk
  - Pollock Service Desk
  - Findlay Service Desk

### Changed
- Dashboard layout updated to move KPI counts into the top header area for more workspace.
- Low Supplies table `Location` renamed to `Served By`.
- Empty Trays table now includes `Served By`.
- Empty Trays `Description` column mirrors tray label (as requested).
- Alert thresholds for consumables enforced as:
  - Red: value < 2
  - Yellow: value 2-15
- Belt/Fuser alerts limited to value `0` only.

### Removed
- Top-bar toner and fuser threshold input controls.
