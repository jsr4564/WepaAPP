# GitHub Release Checklist

## 1. Preflight

- Confirm code compiles:
  - `python3 -m py_compile main.py`
- Confirm README and changelog are up to date:
  - `README.md`
  - `CHANGELOG.md`

## 2. Build Artifacts

### macOS

- `./packaging/build_macos_dmg.sh 1.2.0`
- Verify outputs:
  - `release/macos/PrinterSupplyTrayMonitor-1.2.0.pkg`
  - `release/macos/PrinterSupplyTrayMonitor-1.2.0.dmg`

### Windows (run on Windows)

- `.\packaging\build_windows_exe.ps1 -Version 1.2.0`
- Verify outputs:
  - `release\windows\PrinterSupplyTrayMonitor-1.2.0.exe`
  - `release\windows\PrinterSupplyTrayMonitor-1.2.0-setup.exe` (if Inno Setup installed)

## 3. Checksums

- Generate SHA-256 checksums for all release artifacts and include them in the release notes.

## 4. GitHub Release

- Create tag: `v1.2.0`
- Create release title: `Printer Supply & Tray Monitor v1.2.0`
- Release notes:
  - Copy highlights from `CHANGELOG.md`
  - Include installer notes for macOS and Windows
  - Include SHA-256 checksums
- Upload assets:
  - `.dmg` and `.pkg` from macOS build
  - Windows `.exe` and setup `.exe`

## 5. Post-Release Verification

- Download and run artifacts from the GitHub release page.
- Verify:
  - App launches
  - Monitor refresh works
  - Alert History records both tray and low-supply events
  - CSV export contains both tray and low-supply history rows
